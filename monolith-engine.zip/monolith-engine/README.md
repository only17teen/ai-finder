# Monolith Engine

**One engine** that unifies the best of `ai-finder`, `comfyui-engine`, and
`persona-engine` into a single async pipeline: **discover → score → generate → ship**
an SEO-optimized Next.js blog.

> ✅ **Verified**: the generated Next.js project compiles with `npm run build` —
> all routes prerendered to static HTML (home, posts, tag pages, sitemap, robots),
> ~94 kB First Load JS. Engine itself: **62 tests green**.

## Run from a config file

```bash
monolith run --config config.example.yaml   # declarative JSON/YAML run
```

```
        discover ──▶ score  ─┐
            │                ├──▶ build  ──▶ ship
            └──────▶ enrich ─┘
        (each stage: checkpoint-skip ▸ circuit breaker ▸ retry ▸ timeout)
```

## What's built (core, tested)

| Module | Responsibility |
|--------|----------------|
| `config.py` | One Pydantic v2 schema for an entire run (retry, circuit, pipeline). |
| `core/pipeline.py` | Async **stage DAG** with topological levels + bounded parallelism. |
| `core/resilience.py` | **Circuit breaker** (closed/open/half-open) + async **retry** w/ backoff+jitter. |
| `core/checkpoint.py` | Atomic, crash-safe **resume-from-checkpoint**. |
| `core/engine.py` | The **orchestrator**: composes all of the above into one run loop. |
| `core/exceptions.py` | Typed error hierarchy. |
| `cli.py` | `monolith doctor` · `monolith demo` · `monolith version`. |

## Quick start

```bash
make install          # venv + dev deps
make test             # 15 tests, all green
make demo             # runs the built-in diamond-DAG demo
.venv/bin/monolith doctor
```

## Design principles (from your repos)

- **Async-first** — `asyncio` everywhere, bounded concurrency via semaphore.
- **Resilient by default** — every stage runs inside circuit breaker → retry → timeout.
- **Resumable** — successful stages are checkpointed; reruns skip completed work.
- **Strictly typed & validated** — Pydantic v2 config, `forbid` extras, full type hints.
- **Lightweight core** — only `pydantic` at runtime; heavy subsystems are opt-in extras.

## Discovery subsystem (built, tested) — ai-finder DNA

`discovery/` plugs straight into the core DAG: **collect → dedup → score → store**.

| Module | What it does |
|--------|--------------|
| `discovery/collectors.py` | Async `Collector` base + concurrent, failure-isolated runner |
| `discovery/dedup.py` | **MinHash + LSH** near-duplicate detection (pure stdlib) + exact domain dedup |
| `discovery/store.py` | Async-wrapped **SQLite** store with idempotent upsert + ranked reads |
| `discovery/stage.py` | `CollectStage`, `DedupStage`, `ScoreStage`, `StoreStage` |

```bash
.venv/bin/monolith discover     # runs the full discovery pipeline on seed data
```

## Output subsystem (built, tested) — the Next.js scaffolder

`output/` turns posts (or discovered items) into a complete, **buildable Next.js 14**
project — static-exported, SEO-optimized, dark-mode aware.

| Module | What it does |
|--------|--------------|
| `output/markdown.py` | Compact Markdown → HTML (pure stdlib, HTML-escaped) |
| `output/templates.py` | All Next.js files (App Router, Tailwind, components) as templates |
| `output/scaffold.py` | Async `NextScaffolder` → writes the full project tree |
| `output/stage.py` | `ScaffoldStage` + `items_to_posts` (bridges discovery → output) |

**Generated site features:** App Router · static export (`output: export`) ·
per-post `generateMetadata` + `generateStaticParams` · JSON-LD `BlogPosting` ·
`sitemap.xml` · `robots.txt` · Open Graph + Twitter cards · Tailwind + dark mode ·
pre-rendered HTML (zero markdown runtime deps).

```bash
.venv/bin/monolith scaffold                # generates ./generated-blog
cd generated-blog && npm install && npm run build   # -> ./out (deploy anywhere)
```

## Generation subsystem (built, tested) — persona-engine DNA

`generation/` authors posts in a consistent voice, evolves prompts genetically,
and supports hot-reloadable plugins.

| Module | What it does |
|--------|--------------|
| `generation/writer.py` | `Writer` protocol · deterministic `TemplateWriter` · `CallableWriter` (LLM hook) |
| `generation/evolution.py` | `GeneticOptimizer` + `PromptEvolver` (elitism, tournament, mutation, crossover) |
| `generation/plugins.py` | `PluginManager` with **mtime-based hot reload** + `Registry` |
| `generation/stage.py` | `GenerateStage` + `items_to_topics` (bridges discovery → generation) |

Offline-first (no API key needed). Swap in an LLM by wrapping it in `CallableWriter`.

```bash
.venv/bin/monolith generate     # discover -> persona-author -> scaffold, end-to-end
```

## Observability & deploy (built, tested) — comfyui-engine DNA

Prometheus-compatible metrics (pure stdlib) wired into the engine, plus full
deployment manifests.

| Piece | What it does |
|-------|--------------|
| `observability/metrics.py` | `Counter` / `Gauge` / `Histogram` + registry + Prometheus text renderer + threaded `/metrics` server |
| `observability/__init__.py` | `EngineMetrics` — standard metric set the engine records |
| `Dockerfile` | Multi-stage, non-root, healthcheck, exposes `:9090` |
| `docker-compose.yml` | Engine + Prometheus, one `docker compose up` |
| `deploy/k8s/` | `Deployment`, `Service`, `ServiceMonitor` (scrape annotations) |
| `deploy/helm/` | Chart + values + templated deployment |
| `deploy/terraform/` | Kubernetes provider deployment |
| `monitoring/prometheus.yml` | Scrape config |

Pass `metrics=build_engine_metrics()` to `Engine(...)` to record
`monolith_stage_total`, `monolith_stage_duration_seconds`, and `monolith_run_total`.

```bash
docker compose up --build     # engine + Prometheus
kubectl apply -f deploy/k8s/  # or: helm install monolith deploy/helm/
```

## Roadmap

1. ✅ `discovery/` — concurrent collectors, MinHash/LSH dedup, SQLite store *(ai-finder DNA)*.
2. ✅ `generation/` — persona runtime, prompt evolution, plugin hot-reload *(persona-engine DNA)*.
3. ✅ `output/` — async → Next.js 14 scaffolder (SSG, JSON-LD, sitemap, Tailwind).
4. ✅ `observability/` + `deploy/` — Prometheus metrics, Docker, k8s, Helm, Terraform *(comfyui-engine DNA)*.

**All four branches complete. One engine, end to end.**

## License

MIT
