"""Static file templates for the generated Next.js 14 blog.

Templates use ``%%KEY%%`` sentinels (replaced verbatim by the scaffolder) so
they never clash with JSX/TS braces or template literals. Per-post content is
injected as a typed data module, and Markdown is pre-rendered to HTML at build
time — the generated site ships with zero markdown runtime deps.
"""

from __future__ import annotations

# --- config / tooling -------------------------------------------------------

PACKAGE_JSON = """{
  "name": "%%SLUG%%",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "14.2.5",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@types/node": "^20",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "autoprefixer": "^10.4.19",
    "postcss": "^8.4.39",
    "tailwindcss": "^3.4.6",
    "typescript": "^5.5.3"
  }
}
"""

NEXT_CONFIG = """/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  images: { unoptimized: true },
  trailingSlash: true,
};

export default nextConfig;
"""

TSCONFIG = """{
  "compilerOptions": {
    "target": "ES2017",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [{ "name": "next" }],
    "paths": { "@/*": ["./src/*"] }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
"""

TAILWIND_CONFIG = """import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "media",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { accent: "%%ACCENT%%" },
    },
  },
  plugins: [],
};

export default config;
"""

POSTCSS_CONFIG = """export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
"""

GITIGNORE = """/node_modules
/.next
/out
/build
.DS_Store
*.tsbuildinfo
next-env.d.ts
"""

# --- app shell --------------------------------------------------------------

GLOBALS_CSS = """@tailwind base;
@tailwind components;
@tailwind utilities;

:root { color-scheme: light dark; }

a { color: %%ACCENT%%; }

.prose-custom h2 { font-size: 1.5rem; font-weight: 600; margin-top: 2rem; margin-bottom: .75rem; }
.prose-custom h3 { font-size: 1.25rem; font-weight: 600; margin-top: 1.5rem; margin-bottom: .5rem; }
.prose-custom p { margin-bottom: 1rem; }
.prose-custom ul { list-style: disc; padding-left: 1.5rem; margin-bottom: 1rem; }
.prose-custom ol { list-style: decimal; padding-left: 1.5rem; margin-bottom: 1rem; }
.prose-custom pre { background: #0f172a; color: #e2e8f0; padding: 1rem; border-radius: .5rem; overflow-x: auto; margin-bottom: 1rem; }
.prose-custom code { font-family: ui-monospace, monospace; font-size: .9em; }
.prose-custom blockquote { border-left: 3px solid %%ACCENT%%; padding-left: 1rem; color: #6b7280; margin-bottom: 1rem; }
"""

LAYOUT_TSX = """import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: site.name, template: `%s | ${site.name}` },
  description: site.description,
  openGraph: {
    title: site.name,
    description: site.description,
    url: site.url,
    siteName: site.name,
    type: "website",
  },
  twitter: { card: "summary_large_image", title: site.name, description: site.description },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="%%LOCALE%%" suppressHydrationWarning>
      <body className="min-h-screen bg-white text-gray-900 antialiased dark:bg-gray-950 dark:text-gray-100">
        <Header />
        <main className="mx-auto w-full max-w-3xl px-4 py-10">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
"""

HOME_PAGE_TSX = """import PostCard from "@/components/PostCard";
import { getAllPosts } from "@/lib/posts";
import { site } from "@/lib/site";

export default function HomePage() {
  const posts = getAllPosts();
  return (
    <div className="space-y-8">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">{site.name}</h1>
        <p className="text-gray-600 dark:text-gray-400">{site.description}</p>
      </header>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        {posts.map((post) => (
          <PostCard key={post.slug} post={post} />
        ))}
      </div>
    </div>
  );
}
"""

BLOG_POST_TSX = """import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getAllPosts, getPostBySlug } from "@/lib/posts";
import { site } from "@/lib/site";

export function generateStaticParams() {
  return getAllPosts().map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const post = getPostBySlug(params.slug);
  if (!post) return {};
  const url = `${site.url}/blog/${post.slug}`;
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: url },
    openGraph: {
      title: post.title,
      description: post.excerpt,
      url,
      type: "article",
      publishedTime: post.date,
      images: post.coverImage ? [{ url: post.coverImage }] : undefined,
    },
    twitter: { card: "summary_large_image", title: post.title, description: post.excerpt },
  };
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = getPostBySlug(params.slug);
  if (!post) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    datePublished: post.date,
    author: { "@type": "Person", name: post.author || site.author },
    ...(post.coverImage ? { image: post.coverImage } : {}),
  };

  return (
    <article className="prose-custom">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <h1 className="text-3xl font-bold tracking-tight">{post.title}</h1>
      <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
        <time dateTime={post.date}>{post.date}</time> · {post.readingTime} min read
      </p>
      <div className="mt-8 leading-7" dangerouslySetInnerHTML={{ __html: post.html }} />
    </article>
  );
}
"""

SITEMAP_TS = """import type { MetadataRoute } from "next";
import { getAllPosts, getAllTags } from "@/lib/posts";
import { site } from "@/lib/site";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const posts = getAllPosts().map((p) => ({
    url: `${site.url}/blog/${p.slug}`,
    lastModified: p.date,
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));
  const tags = getAllTags().map((t) => ({
    url: `${site.url}/tags/${t}`,
    changeFrequency: "weekly" as const,
    priority: 0.5,
  }));
  return [
    { url: site.url, lastModified: new Date().toISOString(), changeFrequency: "daily", priority: 1 },
    { url: `${site.url}/tags`, changeFrequency: "weekly", priority: 0.4 },
    ...posts,
    ...tags,
  ];
}
"""

ROBOTS_TS = """import type { MetadataRoute } from "next";
import { site } from "@/lib/site";

export const dynamic = "force-static";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/" },
    sitemap: `${site.url}/sitemap.xml`,
  };
}
"""

# --- lib / types / components ------------------------------------------------

TYPES_TS = """export interface Post {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  tags: string[];
  coverImage: string;
  html: string;
  readingTime: number;
}
"""

SITE_TS = """export const site = {
  name: "%%SITE_NAME%%",
  url: "%%SITE_URL%%",
  description: "%%SITE_DESCRIPTION%%",
  author: "%%SITE_AUTHOR%%",
  locale: "%%LOCALE%%",
} as const;
"""

POSTS_TS = """import type { Post } from "@/types";

export const posts: Post[] = %%POSTS_JSON%%;
"""

LIB_POSTS_TS = """import { posts } from "@/content/posts";
import type { Post } from "@/types";

export function getAllPosts(): Post[] {
  return [...posts].sort((a, b) => (a.date < b.date ? 1 : -1));
}

export function getPostBySlug(slug: string): Post | undefined {
  return posts.find((p) => p.slug === slug);
}

export function getAllTags(): string[] {
  return Array.from(new Set(posts.flatMap((p) => p.tags))).sort();
}

export function getPostsByTag(tag: string): Post[] {
  return getAllPosts().filter((p) => p.tags.includes(tag));
}
"""

TAGS_INDEX_TSX = """import Link from "next/link";
import { getAllTags } from "@/lib/posts";

export const metadata = { title: "Tags" };

export default function TagsPage() {
  const tags = getAllTags();
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">Tags</h1>
      <ul className="flex flex-wrap gap-3">
        {tags.map((tag) => (
          <li key={tag}>
            <Link
              href={`/tags/${tag}`}
              className="rounded-full border border-gray-200 px-3 py-1 text-sm text-gray-700 hover:border-gray-300 dark:border-gray-800 dark:text-gray-300"
            >
              #{tag}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
"""

TAG_PAGE_TSX = """import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import { getAllTags, getPostsByTag } from "@/lib/posts";
import { site } from "@/lib/site";

export function generateStaticParams() {
  return getAllTags().map((tag) => ({ tag }));
}

export function generateMetadata({ params }: { params: { tag: string } }): Metadata {
  return {
    title: `#${params.tag}`,
    description: `Posts tagged ${params.tag} on ${site.name}.`,
    alternates: { canonical: `${site.url}/tags/${params.tag}` },
  };
}

export default function TagPage({ params }: { params: { tag: string } }) {
  const posts = getPostsByTag(params.tag);
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">#{params.tag}</h1>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        {posts.map((post) => (
          <PostCard key={post.slug} post={post} />
        ))}
      </div>
    </div>
  );
}
"""

HEADER_TSX = """import Link from "next/link";
import { site } from "@/lib/site";

export default function Header() {
  return (
    <header className="border-b border-gray-200 dark:border-gray-800">
      <nav className="mx-auto flex w-full max-w-3xl items-center justify-between px-4 py-4">
        <Link href="/" className="font-semibold tracking-tight">
          {site.name}
        </Link>
        <div className="flex gap-4 text-sm text-gray-600 dark:text-gray-400">
          <Link href="/" className="hover:text-gray-900 dark:hover:text-gray-100">
            Home
          </Link>
          <Link href="/tags" className="hover:text-gray-900 dark:hover:text-gray-100">
            Tags
          </Link>
        </div>
      </nav>
    </header>
  );
}
"""

FOOTER_TSX = """import { site } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="border-t border-gray-200 dark:border-gray-800">
      <div className="mx-auto w-full max-w-3xl px-4 py-8 text-sm text-gray-500 dark:text-gray-400">
        © {new Date().getFullYear()} {site.name}. Built with Monolith Engine.
      </div>
    </footer>
  );
}
"""

POSTCARD_TSX = """import Link from "next/link";
import type { Post } from "@/types";

export default function PostCard({ post }: { post: Post }) {
  return (
    <Link
      href={`/blog/${post.slug}`}
      className="group flex flex-col rounded-xl border border-gray-200 p-5 transition hover:border-gray-300 hover:shadow-sm dark:border-gray-800 dark:hover:border-gray-700"
    >
      <h2 className="text-lg font-semibold tracking-tight group-hover:underline">{post.title}</h2>
      <p className="mt-2 line-clamp-3 text-sm text-gray-600 dark:text-gray-400">{post.excerpt}</p>
      <span className="mt-4 text-xs text-gray-500 dark:text-gray-500">
        {post.date} · {post.readingTime} min read
      </span>
    </Link>
  );
}
"""

SITE_README = """# %%SITE_NAME%%

%%SITE_DESCRIPTION%%

Generated by **Monolith Engine**. Static-exported Next.js 14 (App Router).

## Develop

```bash
npm install
npm run dev
```

## Build (static export)

```bash
npm run build      # outputs to ./out — deploy to any static host / CDN
```

SEO is built in: per-post `generateMetadata`, Open Graph + Twitter cards,
JSON-LD `BlogPosting` schema, `sitemap.xml`, and `robots.txt`.
"""

# Map of relative output path -> template body.
FILES: dict[str, str] = {
    "package.json": PACKAGE_JSON,
    "next.config.mjs": NEXT_CONFIG,
    "tsconfig.json": TSCONFIG,
    "tailwind.config.ts": TAILWIND_CONFIG,
    "postcss.config.mjs": POSTCSS_CONFIG,
    ".gitignore": GITIGNORE,
    "README.md": SITE_README,
    "src/app/globals.css": GLOBALS_CSS,
    "src/app/layout.tsx": LAYOUT_TSX,
    "src/app/page.tsx": HOME_PAGE_TSX,
    "src/app/blog/[slug]/page.tsx": BLOG_POST_TSX,
    "src/app/sitemap.ts": SITEMAP_TS,
    "src/app/robots.ts": ROBOTS_TS,
    "src/types/index.ts": TYPES_TS,
    "src/lib/site.ts": SITE_TS,
    "src/lib/posts.ts": LIB_POSTS_TS,
    "src/content/posts.ts": POSTS_TS,
    "src/app/tags/page.tsx": TAGS_INDEX_TSX,
    "src/app/tags/[tag]/page.tsx": TAG_PAGE_TSX,
    "src/components/Header.tsx": HEADER_TSX,
    "src/components/Footer.tsx": FOOTER_TSX,
    "src/components/PostCard.tsx": POSTCARD_TSX,
}
"""@type: ignore"""
