"""Async Next.js project scaffolder.

Renders the template set + a typed posts data module into a complete, buildable
Next.js 14 project. File writes run in threads so the build never blocks the
event loop (no third-party deps required).
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from xml.sax.saxutils import escape

from .markdown import md_to_html
from .models import Post, SiteConfig, slugify
from .templates import FILES

logger = logging.getLogger("monolith.output")


def _rss_feed(site: SiteConfig, posts: list[Post]) -> str:
    """Build an RSS 2.0 feed served statically at /feed.xml."""
    base = str(site.url).rstrip("/")
    items = []
    for p in posts:
        link = f"{base}/blog/{p.slug}"
        items.append(
            "<item>"
            f"<title>{escape(p.title)}</title>"
            f"<link>{escape(link)}</link>"
            f"<guid isPermaLink=\"true\">{escape(link)}</guid>"
            f"<description>{escape(p.excerpt)}</description>"
            f"<pubDate>{escape(p.date)}</pubDate>"
            + "".join(f"<category>{escape(t)}</category>" for t in p.tags)
            + "</item>"
        )
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<rss version="2.0"><channel>'
        f"<title>{escape(site.name)}</title>"
        f"<link>{escape(base)}</link>"
        f"<description>{escape(site.description)}</description>"
        + "".join(items)
        + "</channel></rss>\n"
    )


def _posts_payload(posts: list[Post]) -> str:
    """Serialize posts to a TS-compatible JSON array (with pre-rendered HTML)."""
    data = [
        {
            "slug": p.slug,
            "title": p.title,
            "excerpt": p.excerpt,
            "date": p.date,
            "author": p.author,
            "tags": p.tags,
            "coverImage": p.cover_image,
            "html": md_to_html(p.content_md),
            "readingTime": p.reading_time,
        }
        for p in posts
    ]
    return json.dumps(data, indent=2, ensure_ascii=False)


class NextScaffolder:
    """Turns a :class:`SiteConfig` + posts into a Next.js project on disk."""

    def __init__(self, site: SiteConfig, posts: list[Post]) -> None:
        self.site = site
        self.posts = posts

    def _replacements(self) -> dict[str, str]:
        return {
            "%%SITE_NAME%%": self.site.name,
            "%%SITE_URL%%": str(self.site.url).rstrip("/"),
            "%%SITE_DESCRIPTION%%": self.site.description,
            "%%SITE_AUTHOR%%": self.site.author,
            "%%ACCENT%%": self.site.accent,
            "%%LOCALE%%": self.site.locale,
            "%%SLUG%%": slugify(self.site.name),
            "%%POSTS_JSON%%": _posts_payload(self.posts),
        }

    def _render(self, body: str, repl: dict[str, str]) -> str:
        for token, value in repl.items():
            body = body.replace(token, value)
        return body

    def _write_sync(self, out_dir: Path) -> list[str]:
        repl = self._replacements()
        written: list[str] = []
        for rel, body in FILES.items():
            target = out_dir / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(self._render(body, repl), encoding="utf-8")
            written.append(rel)
        # RSS feed (served at /feed.xml by Next static export of public/)
        feed_rel = "public/feed.xml"
        feed_target = out_dir / feed_rel
        feed_target.parent.mkdir(parents=True, exist_ok=True)
        feed_target.write_text(_rss_feed(self.site, self.posts), encoding="utf-8")
        written.append(feed_rel)
        return sorted(written)

    async def build(self, out_dir: Path | str) -> list[str]:
        out = Path(out_dir)
        written = await asyncio.to_thread(self._write_sync, out)
        logger.info("scaffolded %d files into %s", len(written), out)
        return written
