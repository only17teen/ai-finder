"""Compact Markdown -> HTML converter (pure stdlib).

Supports the subset needed for clean blog posts: ATX headings, fenced code
blocks, unordered/ordered lists, blockquotes, paragraphs, and inline
**bold**, *italic*, `code`, and [links](url). HTML-escapes text so generated
content is safe to inject as pre-rendered HTML in the Next.js site.
"""

from __future__ import annotations

import html
import re

_INLINE_CODE = re.compile(r"`([^`]+)`")
_BOLD = re.compile(r"\*\*([^*]+)\*\*")
_ITALIC = re.compile(r"(?<!\*)\*([^*]+)\*(?!\*)")
_LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def _inline(text: str) -> str:
    text = html.escape(text, quote=False)
    # links first (before italic/bold so URLs are untouched)
    text = _LINK.sub(lambda m: f'<a href="{html.escape(m.group(2), quote=True)}">{m.group(1)}</a>', text)
    text = _INLINE_CODE.sub(lambda m: f"<code>{m.group(1)}</code>", text)
    text = _BOLD.sub(lambda m: f"<strong>{m.group(1)}</strong>", text)
    text = _ITALIC.sub(lambda m: f"<em>{m.group(1)}</em>", text)
    return text


def md_to_html(md: str) -> str:
    """Render a Markdown subset to an HTML string."""
    lines = md.replace("\r\n", "\n").split("\n")
    out: list[str] = []
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]

        # fenced code block
        if line.strip().startswith("```"):
            lang = line.strip()[3:].strip()
            i += 1
            buf: list[str] = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(html.escape(lines[i], quote=False))
                i += 1
            i += 1  # skip closing fence
            cls = f' class="language-{html.escape(lang)}"' if lang else ""
            out.append(f"<pre><code{cls}>{chr(10).join(buf)}</code></pre>")
            continue

        # blank line
        if not line.strip():
            i += 1
            continue

        # heading
        m = re.match(r"(#{1,6})\s+(.*)", line)
        if m:
            level = len(m.group(1))
            out.append(f"<h{level}>{_inline(m.group(2).strip())}</h{level}>")
            i += 1
            continue

        # blockquote
        if line.startswith(">"):
            buf = []
            while i < n and lines[i].startswith(">"):
                buf.append(_inline(lines[i].lstrip(">").strip()))
                i += 1
            out.append(f"<blockquote>{' '.join(buf)}</blockquote>")
            continue

        # unordered list
        if re.match(r"[-*+]\s+", line):
            buf = []
            while i < n and re.match(r"[-*+]\s+", lines[i]):
                buf.append(f"<li>{_inline(re.sub(r'^[-*+]\s+', '', lines[i]))}</li>")
                i += 1
            out.append(f"<ul>{''.join(buf)}</ul>")
            continue

        # ordered list
        if re.match(r"\d+\.\s+", line):
            buf = []
            while i < n and re.match(r"\d+\.\s+", lines[i]):
                buf.append(f"<li>{_inline(re.sub(r'^\d+\.\s+', '', lines[i]))}</li>")
                i += 1
            out.append(f"<ol>{''.join(buf)}</ol>")
            continue

        # paragraph (gather until blank)
        buf = []
        while i < n and lines[i].strip() and not re.match(r"(#{1,6}\s|[-*+]\s|\d+\.\s|>|```)", lines[i]):
            buf.append(_inline(lines[i].strip()))
            i += 1
        out.append(f"<p>{' '.join(buf)}</p>")

    return "\n".join(out)
