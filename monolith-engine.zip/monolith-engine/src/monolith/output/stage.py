"""Output stage: scaffold a Next.js blog from posts on the context bus."""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from ..core.pipeline import Context, Stage
from ..discovery.models import Item
from .models import Post, SiteConfig
from .scaffold import NextScaffolder


def items_to_posts(items: Sequence[Item]) -> list[Post]:
    """Adapt discovered items into draft posts (bridges discovery -> output)."""
    return [Post(title=it.title or it.key, content_md=it.text or it.title) for it in items]


class ScaffoldStage(Stage):
    """Render the Next.js project from ``ctx['posts']`` (or discovered items)."""

    name = "scaffold"

    def __init__(
        self,
        site: SiteConfig,
        out_dir: Path | str,
        *,
        deps: Sequence[str] = (),
        from_items: bool = False,
    ) -> None:
        super().__init__(name="scaffold", deps=deps)
        self._site = site
        self._out = Path(out_dir)
        self._from_items = from_items

    async def run(self, ctx: Context) -> dict[str, int]:
        posts: list[Post] = ctx.get("posts", [])
        if not posts and self._from_items:
            posts = items_to_posts(ctx.get("items", []))
        scaffolder = NextScaffolder(self._site, posts)
        written = await scaffolder.build(self._out)
        ctx.meta["scaffold_out"] = str(self._out)
        return {"files": len(written), "posts": len(posts)}
