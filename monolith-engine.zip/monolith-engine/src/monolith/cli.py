"""Command-line interface for the Monolith Engine.

Commands:
    monolith doctor        Validate environment & config, print engine health.
    monolith demo          Run a built-in demo pipeline end-to-end.
    monolith version       Print version.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys

from . import __version__
from .config import EngineConfig
from .core import Context, Engine, FnStage, Pipeline


def _build_demo_pipeline() -> Pipeline:
    """A tiny 4-stage diamond DAG: discover -> (score, enrich) -> build."""

    async def discover(ctx: Context) -> int:
        ctx.put("topics", ["async", "rust", "edge-ai"])
        return len(ctx.get("topics"))

    async def score(ctx: Context) -> list[str]:
        return sorted(ctx.get("topics", []), reverse=True)

    async def enrich(ctx: Context) -> dict[str, int]:
        return {t: len(t) for t in ctx.get("topics", [])}

    async def build(ctx: Context) -> str:
        return f"built {len(ctx.get('topics', []))} pages"

    return (
        Pipeline()
        .add(FnStage("discover", discover))
        .add(FnStage("score", score, deps=["discover"]))
        .add(FnStage("enrich", enrich, deps=["discover"]))
        .add(FnStage("build", build, deps=["score", "enrich"]))
    )


def _cmd_doctor(args: argparse.Namespace) -> int:
    try:
        cfg = EngineConfig(project_name=args.project)
    except Exception as exc:  # noqa: BLE001
        print(f"✗ config invalid: {exc}", file=sys.stderr)
        return 1
    print("✓ config valid")
    print(f"  project    : {cfg.project_name}")
    print(f"  workdir    : {cfg.workdir}")
    print(f"  max_parallel: {cfg.pipeline.max_parallel}")
    print(f"  retry      : {cfg.retry.max_attempts} attempts")
    print(f"  circuit    : trip @ {cfg.circuit.failure_threshold} failures")
    return 0


def _cmd_discover(args: argparse.Namespace) -> int:
    """Run the discovery pipeline (collect -> dedup -> score -> store) on seed data."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    from .core import Context, Pipeline
    from .discovery import (
        CollectStage,
        DedupStage,
        Item,
        ScoreStage,
        StaticCollector,
        StoreStage,
    )

    seeds = [
        StaticCollector(
            "seed-a",
            [
                Item(url="https://geekai.co", title="GeekAI", text="ai service " * 120),
                Item(url="https://example.org", title="Example", text="short note"),
            ],
        ),
        StaticCollector(
            "seed-b",
            [
                Item(url="https://geekai.co/pricing", title="GeekAI Pricing"),  # domain dup
                Item(url="https://niche.dev", title="Niche", text="self hosted llm hub " * 40),
            ],
        ),
    ]
    cfg = EngineConfig(project_name=args.project, resume=False)
    db = cfg.workdir / "discovery.db"
    pipe = (
        Pipeline()
        .add(CollectStage(seeds))
        .add(DedupStage(threshold=0.8))
        .add(ScoreStage())
        .add(StoreStage(db))
    )
    ctx = Context()
    report = asyncio.run(Engine(cfg, pipe).run(ctx))
    print(f"ok={report.ok} duration={report.duration_s:.3f}s")
    print(f"  stages   : {report.succeeded}")
    print(f"  stored   : {ctx.meta.get('store_count')} items in {db}")
    for it in ctx.get("items", []):
        print(f"    {it.score:>5.2f}  {it.key:<18} {it.title}")
    return 0 if report.ok else 1


def _cmd_run(args: argparse.Namespace) -> int:
    """Run the engine from a declarative config file (JSON or YAML)."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    from .core import Context
    from .loaders import build_blog_pipeline, load_run_config

    spec = load_run_config(args.config)
    pipe = build_blog_pipeline(spec)
    ctx = Context()
    ctx.put("topics", spec.topics)
    report = asyncio.run(Engine(spec.engine, pipe).run(ctx))
    print(f"ok={report.ok} duration={report.duration_s:.3f}s")
    print(f"  stages : {report.succeeded}")
    print(f"  posts  : {len(ctx.get('posts', []))}")
    print(f"  output : ./{spec.out_dir}")
    return 0 if report.ok else 1


def _cmd_generate(args: argparse.Namespace) -> int:
    """Full pipeline: discover seeds -> persona-author posts -> scaffold blog."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    from .core import Context, Pipeline
    from .discovery import CollectStage, DedupStage, Item, StaticCollector
    from .generation import EvolutionConfig, GenerateStage, Persona, PromptEvolver
    from .output import ScaffoldStage, SiteConfig

    seeds = [
        StaticCollector(
            "seed",
            [
                Item(url="https://async.dev", title="Async Engines", text="async pipelines and uvloop"),
                Item(url="https://edge.ai", title="Edge AI", text="running models at the edge"),
                Item(url="https://nextjs.org", title="Static Next.js", text="static export and seo"),
            ],
        )
    ]
    persona = Persona(
        name="only17teen",
        tone="punchy",
        voice="clear, technical, and confident",
        traits=["precise", "practical", "opinionated"],
        signature="only17teen",
    )
    evolver = PromptEvolver(
        directives=["concise", "engaging", "practical", "scannable"],
        must_include=["seo-friendly", "well-structured"],
        config=EvolutionConfig(seed=3, generations=20, population_size=20, genome_length=5),
    )
    site = SiteConfig(
        name=args.project,
        url="https://blog.example.com",
        description="Engine-generated, persona-authored, SEO-optimized.",
        author="only17teen",
    )
    out = "generated-blog"
    pipe = (
        Pipeline()
        .add(CollectStage(seeds))
        .add(DedupStage())
        .add(GenerateStage(persona, evolver=evolver, from_items=True, deps=["dedup"]))
        .add(ScaffoldStage(site, out, deps=["generate"]))
    )
    cfg = EngineConfig(project_name=args.project, resume=False)
    ctx = Context()
    report = asyncio.run(Engine(cfg, pipe).run(ctx))
    print(f"ok={report.ok} duration={report.duration_s:.3f}s")
    print(f"  stages : {report.succeeded}")
    print(f"  prompt : {ctx.meta.get('evolved_prompt')}")
    print(f"  posts  : {len(ctx.get('posts', []))} authored by '{persona.name}'")
    print(f"  output : ./{out}  (cd {out} && npm install && npm run build)")
    return 0 if report.ok else 1


def _cmd_scaffold(args: argparse.Namespace) -> int:
    """Generate a sample SEO-optimized Next.js blog into ./generated-blog."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    from .output import NextScaffolder, Post, SiteConfig

    site = SiteConfig(
        name=args.project,
        url="https://blog.example.com",
        description="An engine-generated, SEO-optimized Next.js blog.",
        author="only17teen",
    )
    posts = [
        Post(
            title="Building One Engine to Rule Them All",
            content_md=(
                "# One Engine\n\n"
                "The **Monolith Engine** unifies discovery, generation, and shipping "
                "into a single async pipeline.\n\n"
                "## Why\n\n"
                "Three repos, one resilient core:\n\n"
                "- concurrent discovery\n"
                "- MinHash/LSH dedup\n"
                "- static Next.js output\n\n"
                "Read more at [the docs](https://blog.example.com)."
            ),
            tags=["engine", "async"],
        ),
        Post(
            title="Edge-First Static Sites",
            content_md=(
                "## Fast by default\n\n"
                "Static export means `output: export` and a CDN-ready `./out`.\n\n"
                "```bash\nnpm run build\n```\n\n"
                "Zero server, instant TTFB."
            ),
            tags=["nextjs", "performance"],
        ),
    ]
    out = "generated-blog"
    written = asyncio.run(NextScaffolder(site, posts).build(out))
    print(f"✓ scaffolded {len(written)} files into ./{out}")
    print(f"  posts: {len(posts)}")
    print("  next: cd generated-blog && npm install && npm run build")
    return 0


def _cmd_demo(args: argparse.Namespace) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    cfg = EngineConfig(project_name=args.project, resume=False)
    engine = Engine(cfg, _build_demo_pipeline())
    report = asyncio.run(engine.run())
    print(f"ok={report.ok} duration={report.duration_s:.3f}s")
    print(f"  succeeded: {report.succeeded}")
    print(f"  skipped  : {report.skipped}")
    if report.failed:
        print(f"  failed   : {report.failed}")
    return 0 if report.ok else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="monolith", description="Monolith Engine CLI")
    parser.add_argument("--project", default="monolith-blog", help="Project name.")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("doctor", help="Validate config & environment.")
    sub.add_parser("demo", help="Run the built-in demo pipeline.")
    sub.add_parser("discover", help="Run the discovery pipeline on seed data.")
    sub.add_parser("generate", help="Full pipeline: discover -> generate -> scaffold.")
    sub.add_parser("scaffold", help="Generate a sample Next.js blog.")
    run_p = sub.add_parser("run", help="Run from a declarative config file (JSON/YAML).")
    run_p.add_argument("--config", required=True, help="Path to a JSON/YAML run config.")
    sub.add_parser("version", help="Print version.")

    args = parser.parse_args(argv)
    if args.cmd == "version":
        print(__version__)
        return 0
    if args.cmd == "doctor":
        return _cmd_doctor(args)
    if args.cmd == "demo":
        return _cmd_demo(args)
    if args.cmd == "discover":
        return _cmd_discover(args)
    if args.cmd == "generate":
        return _cmd_generate(args)
    if args.cmd == "scaffold":
        return _cmd_scaffold(args)
    if args.cmd == "run":
        return _cmd_run(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
