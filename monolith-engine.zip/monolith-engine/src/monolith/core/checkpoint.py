"""Crash-safe checkpointing so a run can resume where it stopped.

State is written atomically (temp file + os.replace) to avoid corrupt
checkpoints if the process dies mid-write.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


class Checkpoint:
    """JSON-backed completion tracker keyed by stage name."""

    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._completed: dict[str, Any] = {}
        if self._path.exists():
            self._load()

    @property
    def completed(self) -> dict[str, Any]:
        return dict(self._completed)

    def is_done(self, stage: str) -> bool:
        return stage in self._completed

    def _load(self) -> None:
        try:
            self._completed = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            self._completed = {}

    def mark(self, stage: str, result: Any = None) -> None:
        """Record a stage as complete and persist atomically."""
        self._completed[stage] = result
        self._flush()

    def clear(self) -> None:
        self._completed = {}
        if self._path.exists():
            self._path.unlink()

    def _flush(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(json.dumps(self._completed, default=str, indent=2), encoding="utf-8")
        os.replace(tmp, self._path)  # atomic on POSIX
