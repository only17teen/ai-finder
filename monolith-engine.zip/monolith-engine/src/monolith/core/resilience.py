"""Resilience primitives: async retry + circuit breaker.

These wrap any awaitable so every external/fallible call in the engine inherits
production-grade failure handling without bespoke try/except sprawl.
"""

from __future__ import annotations

import asyncio
import random
import time
from collections.abc import Awaitable, Callable
from enum import Enum
from typing import TypeVar

from .exceptions import CircuitOpenError, RetryExhaustedError

T = TypeVar("T")


async def retry_async(
    func: Callable[[], Awaitable[T]],
    *,
    max_attempts: int = 3,
    base_delay: float = 0.1,
    max_delay: float = 10.0,
    jitter: float = 0.1,
    retry_on: tuple[type[BaseException], ...] = (Exception,),
) -> T:
    """Call ``func`` with exponential backoff + jitter.

    Raises:
        RetryExhaustedError: if every attempt fails. The final cause is chained.
    """
    last_error: BaseException | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return await func()
        except retry_on as exc:  # noqa: PERF203 - clarity over micro-opt
            last_error = exc
            if attempt == max_attempts:
                break
            delay = min(base_delay * (2 ** (attempt - 1)), max_delay)
            delay += random.uniform(0, jitter * delay)
            await asyncio.sleep(delay)
    assert last_error is not None
    raise RetryExhaustedError(max_attempts, last_error) from last_error


class CircuitState(str, Enum):
    CLOSED = "closed"      # healthy, calls flow through
    OPEN = "open"          # tripped, calls rejected fast
    HALF_OPEN = "half_open"  # probing recovery with limited calls


class CircuitBreaker:
    """A single-resource circuit breaker.

    Opens after ``failure_threshold`` consecutive failures, rejects calls for
    ``reset_timeout`` seconds, then allows a limited number of half-open probes
    before fully closing again.
    """

    def __init__(
        self,
        *,
        failure_threshold: int = 5,
        reset_timeout: float = 30.0,
        half_open_max_calls: int = 1,
        time_fn: Callable[[], float] = time.monotonic,
    ) -> None:
        self._failure_threshold = failure_threshold
        self._reset_timeout = reset_timeout
        self._half_open_max_calls = half_open_max_calls
        self._time = time_fn

        self._state = CircuitState.CLOSED
        self._failures = 0
        self._opened_at = 0.0
        self._half_open_calls = 0
        self._lock = asyncio.Lock()

    @property
    def state(self) -> CircuitState:
        return self._state

    def _transition_if_due(self) -> None:
        if self._state is CircuitState.OPEN and (self._time() - self._opened_at) >= self._reset_timeout:
            self._state = CircuitState.HALF_OPEN
            self._half_open_calls = 0

    async def call(self, func: Callable[[], Awaitable[T]]) -> T:
        """Run ``func`` under breaker protection.

        Raises:
            CircuitOpenError: when the breaker is open (or half-open quota spent).
        """
        async with self._lock:
            self._transition_if_due()
            if self._state is CircuitState.OPEN:
                raise CircuitOpenError("circuit is open")
            if self._state is CircuitState.HALF_OPEN:
                if self._half_open_calls >= self._half_open_max_calls:
                    raise CircuitOpenError("half-open call quota exhausted")
                self._half_open_calls += 1

        try:
            result = await func()
        except Exception:
            await self._on_failure()
            raise
        else:
            await self._on_success()
            return result

    async def _on_success(self) -> None:
        async with self._lock:
            self._failures = 0
            self._state = CircuitState.CLOSED
            self._half_open_calls = 0

    async def _on_failure(self) -> None:
        async with self._lock:
            self._failures += 1
            if self._state is CircuitState.HALF_OPEN or self._failures >= self._failure_threshold:
                self._state = CircuitState.OPEN
                self._opened_at = self._time()
