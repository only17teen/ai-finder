"""Strongly-typed exception hierarchy for the Monolith Engine.

Every failure mode in the engine maps to a precise exception so callers can
react programmatically instead of string-matching error messages.
"""

from __future__ import annotations


class MonolithError(Exception):
    """Base class for all engine errors."""


class ConfigError(MonolithError):
    """Raised when configuration is missing, malformed, or inconsistent."""


class StageError(MonolithError):
    """Raised when a pipeline stage fails irrecoverably.

    Carries the offending stage name so the orchestrator can report and
    checkpoint precisely where execution stopped.
    """

    def __init__(self, stage: str, message: str) -> None:
        self.stage = stage
        super().__init__(f"[stage:{stage}] {message}")


class DependencyError(MonolithError):
    """Raised when the pipeline DAG is invalid (missing dep or a cycle)."""


class CircuitOpenError(MonolithError):
    """Raised when a call is rejected because its circuit breaker is open."""


class RetryExhaustedError(MonolithError):
    """Raised when all retry attempts are exhausted.

    Preserves the final underlying exception via ``__cause__``.
    """

    def __init__(self, attempts: int, last_error: BaseException) -> None:
        self.attempts = attempts
        self.last_error = last_error
        super().__init__(f"retry exhausted after {attempts} attempt(s): {last_error!r}")
