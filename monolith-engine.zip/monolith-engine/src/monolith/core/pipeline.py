"""Async stage DAG: the execution heart of the engine.

A ``Pipeline`` is a set of named ``Stage`` objects with declared dependencies.
The runner topologically orders them, then executes each dependency "level"
concurrently (bounded by a semaphore), sharing a single mutable ``Context``.
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from .exceptions import DependencyError, StageError

logger = logging.getLogger("monolith.pipeline")


@dataclass
class Context:
    """Shared, mutable state threaded through every stage.

    ``data`` is the inter-stage bus (a stage reads upstream outputs and writes
    its own). ``meta`` holds run-level info (timings, counters).
    """

    data: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    def put(self, key: str, value: Any) -> None:
        self.data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)


class Stage(ABC):
    """A unit of work. Subclass and implement :meth:`run`."""

    name: str = ""
    deps: tuple[str, ...] = ()

    def __init__(self, name: str | None = None, deps: Iterable[str] | None = None) -> None:
        if name is not None:
            self.name = name
        if deps is not None:
            self.deps = tuple(deps)
        if not self.name:
            raise DependencyError("stage must have a non-empty name")

    @abstractmethod
    async def run(self, ctx: Context) -> Any:
        """Execute the stage. Return value is stored on the context bus."""
        raise NotImplementedError


class FnStage(Stage):
    """Adapter that turns a plain async function into a Stage."""

    def __init__(self, name: str, fn: Any, deps: Iterable[str] | None = None) -> None:
        super().__init__(name=name, deps=deps)
        self._fn = fn

    async def run(self, ctx: Context) -> Any:
        return await self._fn(ctx)


class Pipeline:
    """Holds stages and computes a valid execution order."""

    def __init__(self) -> None:
        self._stages: dict[str, Stage] = {}

    def add(self, stage: Stage) -> Pipeline:
        if stage.name in self._stages:
            raise DependencyError(f"duplicate stage name: {stage.name}")
        self._stages[stage.name] = stage
        return self

    @property
    def stages(self) -> dict[str, Stage]:
        return dict(self._stages)

    def topological_levels(self) -> list[list[str]]:
        """Group stages into dependency levels (each level runs in parallel).

        Raises:
            DependencyError: on a missing dependency or a cycle.
        """
        for s in self._stages.values():
            for dep in s.deps:
                if dep not in self._stages:
                    raise DependencyError(f"stage '{s.name}' depends on unknown stage '{dep}'")

        indegree = {n: len(s.deps) for n, s in self._stages.items()}
        dependents: dict[str, list[str]] = {n: [] for n in self._stages}
        for n, s in self._stages.items():
            for dep in s.deps:
                dependents[dep].append(n)

        levels: list[list[str]] = []
        ready = sorted(n for n, d in indegree.items() if d == 0)
        seen = 0
        while ready:
            levels.append(ready)
            seen += len(ready)
            nxt: list[str] = []
            for n in ready:
                for child in dependents[n]:
                    indegree[child] -= 1
                    if indegree[child] == 0:
                        nxt.append(child)
            ready = sorted(nxt)

        if seen != len(self._stages):
            raise DependencyError("cycle detected in pipeline dependency graph")
        return levels
