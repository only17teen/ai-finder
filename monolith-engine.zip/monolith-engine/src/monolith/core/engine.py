"""The Engine orchestrator — the single 'main engine' entry point.

Composes config + pipeline + resilience + checkpointing into one run loop:

    levels = pipeline.topological_levels()
    for level in levels:
        run level's stages concurrently, each wrapped in:
            checkpoint-skip -> circuit breaker -> retry -> timeout

Successful stages are checkpointed so reruns resume instead of redoing work.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from ..config import EngineConfig
from .checkpoint import Checkpoint
from .exceptions import StageError
from .pipeline import Context, Pipeline, Stage
from .resilience import CircuitBreaker, retry_async

logger = logging.getLogger("monolith.engine")


@dataclass
class RunReport:
    """Outcome of an engine run."""

    succeeded: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    failed: dict[str, str] = field(default_factory=dict)
    duration_s: float = 0.0

    @property
    def ok(self) -> bool:
        return not self.failed


class Engine:
    """Resilient, checkpointed, parallel pipeline orchestrator."""

    def __init__(self, config: EngineConfig, pipeline: Pipeline, *, metrics: Any | None = None) -> None:
        self.config = config
        self.pipeline = pipeline
        self._metrics = metrics
        self._checkpoint = Checkpoint(config.workdir / f"{config.project_name}.checkpoint.json")
        if not config.resume:
            self._checkpoint.clear()
        # One breaker per stage isolates failure domains.
        self._breakers: dict[str, CircuitBreaker] = {}

    def _breaker_for(self, stage: str) -> CircuitBreaker:
        if stage not in self._breakers:
            self._breakers[stage] = CircuitBreaker(
                failure_threshold=self.config.circuit.failure_threshold,
                reset_timeout=self.config.circuit.reset_timeout,
                half_open_max_calls=self.config.circuit.half_open_max_calls,
            )
        return self._breakers[stage]

    async def _execute_stage(self, stage: Stage, ctx: Context) -> Any:
        breaker = self._breaker_for(stage.name)
        r = self.config.retry

        async def _attempt() -> Any:
            return await asyncio.wait_for(stage.run(ctx), timeout=self.config.pipeline.stage_timeout)

        async def _guarded() -> Any:
            # retry sits inside the breaker: a fully-failed retry counts as one
            # breaker failure for that stage.
            return await retry_async(
                _attempt,
                max_attempts=r.max_attempts,
                base_delay=r.base_delay,
                max_delay=r.max_delay,
                jitter=r.jitter,
            )

        return await breaker.call(_guarded)

    async def run(self, ctx: Context | None = None) -> RunReport:
        ctx = ctx or Context()
        report = RunReport()
        started = time.monotonic()
        levels = self.pipeline.topological_levels()
        sem = asyncio.Semaphore(self.config.pipeline.max_parallel)
        aborted = False

        for level in levels:
            if aborted:
                break

            async def _run_one(name: str) -> tuple[str, str | None, Any, float]:
                stage = self.pipeline.stages[name]
                if self._checkpoint.is_done(name):
                    return name, "skip", self._checkpoint.completed[name], 0.0
                async with sem:
                    t0 = time.monotonic()
                    try:
                        result = await self._execute_stage(stage, ctx)
                        return name, None, result, time.monotonic() - t0
                    except Exception as exc:  # noqa: BLE001 - surfaced in report
                        return name, "fail", repr(exc), time.monotonic() - t0

            results = await asyncio.gather(*(_run_one(n) for n in level))

            for name, status, payload, duration in results:
                if status == "skip":
                    report.skipped.append(name)
                    if payload is not None:
                        ctx.put(name, payload)
                    if self._metrics:
                        self._metrics.record_stage(name, "skip", duration)
                elif status == "fail":
                    report.failed[name] = str(payload)
                    logger.error("stage '%s' failed: %s", name, payload)
                    if self._metrics:
                        self._metrics.record_stage(name, "fail", duration)
                    if self.config.pipeline.fail_fast:
                        aborted = True
                else:
                    report.succeeded.append(name)
                    ctx.put(name, payload)
                    self._checkpoint.mark(name, _safe(payload))
                    if self._metrics:
                        self._metrics.record_stage(name, "ok", duration)

        report.duration_s = time.monotonic() - started
        if self._metrics:
            self._metrics.record_run(report.ok)
        return report


def _safe(value: Any) -> Any:
    """Only persist JSON-friendly primitives in the checkpoint."""
    return value if isinstance(value, (str, int, float, bool, type(None), list, dict)) else None
