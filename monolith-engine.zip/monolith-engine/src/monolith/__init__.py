"""Monolith Engine — one engine: discover, score, generate, ship."""

from .config import EngineConfig
from .core import Context, Engine, FnStage, Pipeline, RunReport, Stage

__version__ = "0.2.0"

__all__ = [
    "EngineConfig",
    "Engine",
    "Pipeline",
    "Stage",
    "FnStage",
    "Context",
    "RunReport",
    "__version__",
]
