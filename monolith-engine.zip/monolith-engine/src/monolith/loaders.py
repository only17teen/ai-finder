"""Declarative run configuration loader.

Reads a JSON or YAML file describing an entire engine run (engine config, site,
persona, topics) and builds the pipeline. JSON works with stdlib alone; YAML
requires the optional ``[yaml]`` extra (``pyyaml``).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import EngineConfig
from .core.pipeline import Pipeline
from .generation.models import Persona, Topic
from .generation.stage import GenerateStage
from .output.models import SiteConfig
from .output.stage import ScaffoldStage

_ENGINE_KEYS = {"project_name", "workdir", "resume", "retry", "circuit", "pipeline"}


@dataclass
class RunSpec:
    """A fully-resolved run definition."""

    engine: EngineConfig
    site: SiteConfig
    persona: Persona
    topics: list[Topic] = field(default_factory=list)
    out_dir: str = "generated-blog"


def _read(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError as exc:  # pragma: no cover - depends on env
            raise RuntimeError("YAML configs require the [yaml] extra (pip install pyyaml)") from exc
        return yaml.safe_load(text) or {}
    return json.loads(text)


def load_run_config(path: str | Path) -> RunSpec:
    """Parse a config file into a :class:`RunSpec`."""
    data = _read(path)
    engine = EngineConfig(**{k: v for k, v in data.items() if k in _ENGINE_KEYS})
    site = SiteConfig(**data["site"])
    persona = Persona(**data["persona"])
    topics = [
        Topic(title=t["title"], keywords=t.get("keywords", []), context=t.get("context", ""))
        for t in data.get("topics", [])
    ]
    return RunSpec(engine=engine, site=site, persona=persona, topics=topics,
                   out_dir=data.get("out_dir", "generated-blog"))


def build_blog_pipeline(spec: RunSpec) -> Pipeline:
    """Build a generate -> scaffold pipeline from a run spec."""
    return (
        Pipeline()
        .add(GenerateStage(spec.persona))
        .add(ScaffoldStage(spec.site, spec.out_dir, deps=["generate"]))
    )
