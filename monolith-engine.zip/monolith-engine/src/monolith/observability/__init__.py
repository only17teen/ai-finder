"""Observability: Prometheus-compatible metrics + engine instrumentation."""

from .metrics import (
    Counter,
    Gauge,
    Histogram,
    MetricsRegistry,
    serve_metrics,
)

__all__ = [
    "Counter",
    "Gauge",
    "Histogram",
    "MetricsRegistry",
    "serve_metrics",
    "EngineMetrics",
    "build_engine_metrics",
]


class EngineMetrics:
    """Standard metric set the engine records during a run."""

    def __init__(self, registry: MetricsRegistry) -> None:
        self.registry = registry
        self.stage_total = registry.counter(
            "monolith_stage_total", "Stage executions by status.", ("stage", "status")
        )
        self.stage_duration = registry.histogram(
            "monolith_stage_duration_seconds", "Stage execution time in seconds.", ("stage",)
        )
        self.run_total = registry.counter(
            "monolith_run_total", "Engine runs by outcome.", ("outcome",)
        )

    def record_stage(self, stage: str, status: str, duration: float) -> None:
        self.stage_total.inc(stage=stage, status=status)
        self.stage_duration.observe(duration, stage=stage)

    def record_run(self, ok: bool) -> None:
        self.run_total.inc(outcome="ok" if ok else "failed")


def build_engine_metrics(registry: MetricsRegistry | None = None) -> EngineMetrics:
    return EngineMetrics(registry or MetricsRegistry())
