"""Prometheus-compatible metrics — pure stdlib (no prometheus-client dep).

Provides Counter / Gauge / Histogram with labels, a registry, a text-format
renderer (Prometheus exposition format), and an optional threaded HTTP
``/metrics`` server. Compatible with any Prometheus scraper.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Literal

LabelKey = tuple[tuple[str, str], ...]


def _key(labels: dict[str, str]) -> LabelKey:
    return tuple(sorted(labels.items()))


def _fmt_labels(key: LabelKey, extra: tuple[tuple[str, str], ...] = ()) -> str:
    items = list(key) + list(extra)
    if not items:
        return ""
    inner = ",".join(f'{k}="{v}"' for k, v in items)
    return "{" + inner + "}"


@dataclass
class _Metric:
    name: str
    help: str
    labelnames: tuple[str, ...] = ()
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def _check(self, labels: dict[str, str]) -> None:
        if set(labels) != set(self.labelnames):
            raise ValueError(f"{self.name}: expected labels {self.labelnames}, got {tuple(labels)}")


class Counter(_Metric):
    """Monotonically increasing counter."""

    def __init__(self, name: str, help: str, labelnames: tuple[str, ...] = ()) -> None:
        super().__init__(name=name, help=help, labelnames=labelnames)
        self._values: dict[LabelKey, float] = {}

    def inc(self, amount: float = 1.0, **labels: str) -> None:
        self._check(labels)
        if amount < 0:
            raise ValueError("counter cannot decrease")
        k = _key(labels)
        with self._lock:
            self._values[k] = self._values.get(k, 0.0) + amount

    def value(self, **labels: str) -> float:
        return self._values.get(_key(labels), 0.0)

    def render(self) -> list[str]:
        lines = [f"# HELP {self.name} {self.help}", f"# TYPE {self.name} counter"]
        items = self._values or {(): 0.0}
        for k, v in items.items():
            lines.append(f"{self.name}{_fmt_labels(k)} {v}")
        return lines


class Gauge(_Metric):
    """Value that can go up or down."""

    def __init__(self, name: str, help: str, labelnames: tuple[str, ...] = ()) -> None:
        super().__init__(name=name, help=help, labelnames=labelnames)
        self._values: dict[LabelKey, float] = {}

    def set(self, value: float, **labels: str) -> None:
        self._check(labels)
        with self._lock:
            self._values[_key(labels)] = value

    def inc(self, amount: float = 1.0, **labels: str) -> None:
        self._check(labels)
        k = _key(labels)
        with self._lock:
            self._values[k] = self._values.get(k, 0.0) + amount

    def dec(self, amount: float = 1.0, **labels: str) -> None:
        self.inc(-amount, **labels)

    def value(self, **labels: str) -> float:
        return self._values.get(_key(labels), 0.0)

    def render(self) -> list[str]:
        lines = [f"# HELP {self.name} {self.help}", f"# TYPE {self.name} gauge"]
        items = self._values or {(): 0.0}
        for k, v in items.items():
            lines.append(f"{self.name}{_fmt_labels(k)} {v}")
        return lines


_DEFAULT_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)


class Histogram(_Metric):
    """Cumulative histogram with configurable buckets."""

    def __init__(
        self,
        name: str,
        help: str,
        labelnames: tuple[str, ...] = (),
        buckets: tuple[float, ...] = _DEFAULT_BUCKETS,
    ) -> None:
        super().__init__(name=name, help=help, labelnames=labelnames)
        self.buckets = tuple(sorted(buckets))
        self._counts: dict[LabelKey, list[int]] = {}
        self._sums: dict[LabelKey, float] = {}
        self._totals: dict[LabelKey, int] = {}

    def observe(self, value: float, **labels: str) -> None:
        self._check(labels)
        k = _key(labels)
        with self._lock:
            counts = self._counts.setdefault(k, [0] * len(self.buckets))
            for i, b in enumerate(self.buckets):
                if value <= b:
                    counts[i] += 1
            self._sums[k] = self._sums.get(k, 0.0) + value
            self._totals[k] = self._totals.get(k, 0) + 1

    def render(self) -> list[str]:
        lines = [f"# HELP {self.name} {self.help}", f"# TYPE {self.name} histogram"]
        for k in self._totals:
            cumulative = 0
            counts = self._counts[k]
            for i, b in enumerate(self.buckets):
                cumulative = counts[i]
                lines.append(f"{self.name}_bucket{_fmt_labels(k, (('le', str(b)),))} {cumulative}")
            total = self._totals[k]
            lines.append(f"{self.name}_bucket{_fmt_labels(k, (('le', '+Inf'),))} {total}")
            lines.append(f"{self.name}_sum{_fmt_labels(k)} {self._sums[k]}")
            lines.append(f"{self.name}_count{_fmt_labels(k)} {total}")
        return lines


class MetricsRegistry:
    """Holds metrics and renders them in Prometheus text format."""

    def __init__(self) -> None:
        self._metrics: list[Counter | Gauge | Histogram] = []

    def counter(self, name: str, help: str, labelnames: tuple[str, ...] = ()) -> Counter:
        m = Counter(name=name, help=help, labelnames=labelnames)
        self._metrics.append(m)
        return m

    def gauge(self, name: str, help: str, labelnames: tuple[str, ...] = ()) -> Gauge:
        m = Gauge(name=name, help=help, labelnames=labelnames)
        self._metrics.append(m)
        return m

    def histogram(
        self, name: str, help: str, labelnames: tuple[str, ...] = (), buckets: tuple[float, ...] = _DEFAULT_BUCKETS
    ) -> Histogram:
        m = Histogram(name, help, labelnames, buckets)
        self._metrics.append(m)
        return m

    def render(self) -> str:
        out: list[str] = []
        for m in self._metrics:
            out.extend(m.render())
        return "\n".join(out) + "\n"


def serve_metrics(registry: MetricsRegistry, *, host: str = "0.0.0.0", port: int = 9090) -> ThreadingHTTPServer:
    """Start a background HTTP server exposing ``/metrics``. Returns the server."""

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path.rstrip("/") in ("/metrics", ""):
                body = registry.render().encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; version=0.0.4")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, *args: object) -> None:  # silence access logs
            return

    server = ThreadingHTTPServer((host, port), _Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server
