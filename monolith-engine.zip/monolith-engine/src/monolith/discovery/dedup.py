"""Near-duplicate detection via MinHash + LSH (pure stdlib).

Two-stage dedup, mirroring ai-finder:
1. Exact: collapse by ``Item.key`` (domain).
2. Near: MinHash signatures + LSH banding find items with high Jaccard
   similarity of their shingled text, even across different domains.

No third-party deps — deterministic, fast, and lightweight.
"""

from __future__ import annotations

import hashlib
import random
from collections import defaultdict
from collections.abc import Iterable

from .models import Item

_MERSENNE = (1 << 61) - 1


def _shingles(text: str, k: int = 4) -> set[str]:
    tokens = text.split()
    if not tokens:
        return set()
    if len(tokens) < k:
        return {" ".join(tokens)}
    return {" ".join(tokens[i : i + k]) for i in range(len(tokens) - k + 1)}


def _h64(data: str) -> int:
    return int.from_bytes(hashlib.blake2b(data.encode(), digest_size=8).digest(), "little")


class MinHasher:
    """Computes MinHash signatures using universal hashing."""

    def __init__(self, num_perm: int = 64, seed: int = 1, k: int = 4) -> None:
        self.num_perm = num_perm
        self.k = k
        rng = random.Random(seed)
        self._a = [rng.randrange(1, _MERSENNE) for _ in range(num_perm)]
        self._b = [rng.randrange(0, _MERSENNE) for _ in range(num_perm)]

    def signature(self, text: str) -> tuple[int, ...]:
        sh = _shingles(text, self.k)
        if not sh:
            return tuple([0] * self.num_perm)
        hashes = [_h64(s) for s in sh]
        return tuple(
            min((a * h + b) % _MERSENNE for h in hashes)
            for a, b in zip(self._a, self._b, strict=True)
        )

    @staticmethod
    def jaccard(sig_a: tuple[int, ...], sig_b: tuple[int, ...]) -> float:
        if not sig_a or len(sig_a) != len(sig_b):
            return 0.0
        matches = sum(1 for x, y in zip(sig_a, sig_b, strict=True) if x == y)
        return matches / len(sig_a)


class LSHIndex:
    """Locality-sensitive hashing over MinHash signatures (banding)."""

    def __init__(self, num_perm: int = 64, bands: int = 16) -> None:
        if num_perm % bands != 0:
            raise ValueError("num_perm must be divisible by bands")
        self.bands = bands
        self.rows = num_perm // bands
        self._buckets: dict[tuple[int, tuple[int, ...]], set[str]] = defaultdict(set)
        self._sigs: dict[str, tuple[int, ...]] = {}

    def add(self, key: str, sig: tuple[int, ...]) -> None:
        self._sigs[key] = sig
        for band in range(self.bands):
            chunk = sig[band * self.rows : (band + 1) * self.rows]
            self._buckets[(band, chunk)].add(key)

    def candidates(self, sig: tuple[int, ...]) -> set[str]:
        out: set[str] = set()
        for band in range(self.bands):
            chunk = sig[band * self.rows : (band + 1) * self.rows]
            out |= self._buckets.get((band, chunk), set())
        return out


def deduplicate(
    items: Iterable[Item],
    *,
    threshold: float = 0.8,
    num_perm: int = 64,
    bands: int = 16,
) -> tuple[list[Item], int]:
    """Return (unique_items, dropped_count).

    First collapses exact-key (domain) duplicates, then removes near-duplicates
    above ``threshold`` estimated Jaccard similarity.
    """
    by_key: dict[str, Item] = {}
    exact_dropped = 0
    for it in items:
        if it.key in by_key:
            exact_dropped += 1
            continue
        by_key[it.key] = it

    hasher = MinHasher(num_perm=num_perm)
    index = LSHIndex(num_perm=num_perm, bands=bands)
    kept: list[Item] = []
    near_dropped = 0

    for it in by_key.values():
        sig = hasher.signature(it.fingerprint_text)
        is_dup = any(
            MinHasher.jaccard(sig, index._sigs[c]) >= threshold
            for c in index.candidates(sig)
        )
        if is_dup:
            near_dropped += 1
            continue
        index.add(it.key, sig)
        kept.append(it)

    return kept, exact_dropped + near_dropped
