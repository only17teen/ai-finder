"""Discovery stages that plug into the engine pipeline.

Wires the discovery subsystem into the core DAG:

    collect ──▶ dedup ──▶ score ──▶ store

Each stage reads/writes the shared :class:`~monolith.core.pipeline.Context`
bus under the ``items`` key, so it composes with any other engine stages.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from pathlib import Path

from ..core.pipeline import Context, Stage
from .collectors import Collector, run_collectors
from .dedup import deduplicate
from .models import Item
from .store import SQLiteStore


class CollectStage(Stage):
    """Run all collectors concurrently; put merged items on the bus."""

    name = "collect"

    def __init__(self, collectors: Sequence[Collector], *, max_parallel: int = 8) -> None:
        super().__init__(name="collect")
        self._collectors = collectors
        self._max_parallel = max_parallel

    async def run(self, ctx: Context) -> int:
        items, errors = await run_collectors(self._collectors, max_parallel=self._max_parallel)
        ctx.put("items", items)
        ctx.meta["collector_errors"] = errors
        return len(items)


class DedupStage(Stage):
    """Collapse exact + near duplicates."""

    name = "dedup"

    def __init__(self, *, threshold: float = 0.8, deps: Sequence[str] = ("collect",)) -> None:
        super().__init__(name="dedup", deps=deps)
        self._threshold = threshold

    async def run(self, ctx: Context) -> dict[str, int]:
        items: list[Item] = ctx.get("items", [])
        unique, dropped = deduplicate(items, threshold=self._threshold)
        ctx.put("items", unique)
        return {"kept": len(unique), "dropped": dropped}


def default_scorer(it: Item) -> float:
    """Lightweight relevance heuristic in [0, 1].

    Rewards having a title and richer body text; bounded and deterministic.
    Override by passing your own ``scorer`` to :class:`ScoreStage`.
    """
    title_bonus = 0.4 if it.title.strip() else 0.0
    words = len(it.text.split())
    body = min(words / 200.0, 1.0) * 0.6  # saturates at ~200 words
    return round(title_bonus + body, 4)


class ScoreStage(Stage):
    """Assign a score to each item using a pluggable scorer."""

    name = "score"

    def __init__(
        self,
        scorer: Callable[[Item], float] = default_scorer,
        *,
        deps: Sequence[str] = ("dedup",),
    ) -> None:
        super().__init__(name="score", deps=deps)
        self._scorer = scorer

    async def run(self, ctx: Context) -> int:
        items: list[Item] = ctx.get("items", [])
        for it in items:
            it.score = self._scorer(it)
        items.sort(key=lambda x: x.score, reverse=True)
        ctx.put("items", items)
        return len(items)


class StoreStage(Stage):
    """Persist scored items to SQLite."""

    name = "store"

    def __init__(self, db_path: Path | str, *, deps: Sequence[str] = ("score",)) -> None:
        super().__init__(name="store", deps=deps)
        self._store = SQLiteStore(db_path)

    async def run(self, ctx: Context) -> int:
        await self._store.init()
        items: list[Item] = ctx.get("items", [])
        written = await self._store.upsert(items)
        ctx.meta["store_count"] = await self._store.count()
        return written
