"""Collectors + concurrent runner (ai-finder DNA).

A ``Collector`` is an async source of ``Item``s. ``run_collectors`` executes
many of them concurrently (bounded), isolating failures so one broken source
never sinks the run — failed collectors yield nothing and are reported.
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from collections.abc import Sequence

from .models import Item

logger = logging.getLogger("monolith.discovery")


class Collector(ABC):
    """Abstract source of discovered items."""

    name: str = ""

    def __init__(self, name: str | None = None) -> None:
        if name:
            self.name = name
        if not self.name:
            raise ValueError("collector must have a name")

    @abstractmethod
    async def collect(self) -> list[Item]:
        raise NotImplementedError


class StaticCollector(Collector):
    """Returns a fixed list — useful for tests, seeds, and offline runs."""

    def __init__(self, name: str, items: Sequence[Item]) -> None:
        super().__init__(name=name)
        self._items = list(items)

    async def collect(self) -> list[Item]:
        for it in self._items:
            if not it.source:
                it.source = self.name
        return list(self._items)


async def run_collectors(
    collectors: Sequence[Collector],
    *,
    max_parallel: int = 8,
    timeout: float = 30.0,
) -> tuple[list[Item], dict[str, str]]:
    """Run all collectors concurrently.

    Returns (all_items, errors) where ``errors`` maps collector name -> message.
    """
    sem = asyncio.Semaphore(max_parallel)
    errors: dict[str, str] = {}

    async def _one(c: Collector) -> list[Item]:
        async with sem:
            try:
                items = await asyncio.wait_for(c.collect(), timeout=timeout)
                for it in items:
                    if not it.source:
                        it.source = c.name
                logger.info("collector '%s' -> %d items", c.name, len(items))
                return items
            except Exception as exc:  # noqa: BLE001 - isolate per-source failures
                errors[c.name] = repr(exc)
                logger.error("collector '%s' failed: %r", c.name, exc)
                return []

    results = await asyncio.gather(*(_one(c) for c in collectors))
    merged: list[Item] = [it for batch in results for it in batch]
    return merged, errors
