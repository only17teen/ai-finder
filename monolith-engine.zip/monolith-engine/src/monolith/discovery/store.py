"""Async-friendly SQLite store for discovered items.

sqlite3 is synchronous; every call is wrapped in ``asyncio.to_thread`` so the
store never blocks the event loop — consistent with the engine's async design.
Writes are idempotent upserts keyed by ``Item.key``.
"""

from __future__ import annotations

import asyncio
import sqlite3
from collections.abc import Iterable
from pathlib import Path

from .models import Item

_SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    key           TEXT PRIMARY KEY,
    url           TEXT NOT NULL,
    title         TEXT,
    source        TEXT,
    score         REAL DEFAULT 0,
    discovered_at REAL
);
CREATE INDEX IF NOT EXISTS idx_items_score ON items(score DESC);
"""


class SQLiteStore:
    """Minimal persistent store with upsert + ranked reads."""

    def __init__(self, path: Path | str) -> None:
        self._path = str(path)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_sync(self) -> None:
        Path(self._path).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(_SCHEMA)

    async def init(self) -> None:
        await asyncio.to_thread(self._init_sync)

    def _upsert_sync(self, items: list[Item]) -> int:
        rows = [
            (it.key, it.url, it.title, it.source, it.score, it.discovered_at)
            for it in items
        ]
        with self._connect() as conn:
            conn.executemany(
                """
                INSERT INTO items (key, url, title, source, score, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    score = MAX(items.score, excluded.score),
                    title = COALESCE(NULLIF(excluded.title, ''), items.title)
                """,
                rows,
            )
        return len(rows)

    async def upsert(self, items: Iterable[Item]) -> int:
        batch = list(items)
        if not batch:
            return 0
        return await asyncio.to_thread(self._upsert_sync, batch)

    def _top_sync(self, limit: int) -> list[Item]:
        with self._connect() as conn:
            cur = conn.execute(
                "SELECT * FROM items ORDER BY score DESC, discovered_at DESC LIMIT ?",
                (limit,),
            )
            return [
                Item(
                    url=r["url"],
                    title=r["title"] or "",
                    source=r["source"] or "",
                    score=r["score"],
                    discovered_at=r["discovered_at"] or 0.0,
                    key=r["key"],
                )
                for r in cur.fetchall()
            ]

    async def top(self, limit: int = 20) -> list[Item]:
        return await asyncio.to_thread(self._top_sync, limit)

    async def count(self) -> int:
        def _c() -> int:
            with self._connect() as conn:
                return int(conn.execute("SELECT COUNT(*) FROM items").fetchone()[0])

        return await asyncio.to_thread(_c)
