"""Data models for the discovery subsystem."""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from urllib.parse import urlparse


def _domain(url: str) -> str:
    netloc = urlparse(url).netloc.lower()
    return netloc[4:] if netloc.startswith("www.") else netloc


@dataclass(slots=True)
class Item:
    """A single discovered candidate (e.g. a site/post/service).

    ``key`` defaults to the URL's domain so the same site discovered from
    multiple sources collapses to one identity (ai-finder's "dedup by domain").
    """

    url: str
    title: str = ""
    text: str = ""
    source: str = ""
    score: float = 0.0
    discovered_at: float = field(default_factory=time.time)
    key: str = ""

    def __post_init__(self) -> None:
        if not self.key:
            self.key = _domain(self.url) or hashlib.sha1(self.url.encode()).hexdigest()[:16]

    @property
    def fingerprint_text(self) -> str:
        """Text used for near-duplicate detection."""
        return f"{self.title} {self.text}".strip().lower()
