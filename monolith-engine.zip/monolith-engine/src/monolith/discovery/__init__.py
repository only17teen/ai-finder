"""Discovery subsystem (ai-finder DNA): collect, dedup, score, store."""

from .collectors import Collector, StaticCollector, run_collectors
from .dedup import LSHIndex, MinHasher, deduplicate
from .models import Item
from .stage import CollectStage, DedupStage, ScoreStage, StoreStage, default_scorer
from .store import SQLiteStore

__all__ = [
    "Item",
    "Collector",
    "StaticCollector",
    "run_collectors",
    "MinHasher",
    "LSHIndex",
    "deduplicate",
    "SQLiteStore",
    "CollectStage",
    "DedupStage",
    "ScoreStage",
    "StoreStage",
    "default_scorer",
]
