"""Models for the generation subsystem: personas and topics."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class Persona:
    """A consistent authorial voice for generated content."""

    name: str
    voice: str = "clear, technical, and concise"
    tone: str = "informative"
    traits: list[str] = field(default_factory=lambda: ["precise", "practical"])
    signature: str = ""
    audience: str = "developers"

    def style_brief(self) -> str:
        """A one-line directive describing how this persona writes."""
        traits = ", ".join(self.traits)
        return (
            f"Write in a {self.tone} tone with a {self.voice} voice "
            f"for {self.audience}. Be {traits}."
        )


@dataclass(slots=True)
class Topic:
    """A subject to write about, optionally with seed context."""

    title: str
    keywords: list[str] = field(default_factory=list)
    context: str = ""
