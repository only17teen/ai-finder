"""Genetic prompt evolution (persona-engine DNA).

A generic genetic optimizer over ``list[str]`` genomes (elitism + tournament
selection + point mutation + single-point crossover), plus a ``PromptEvolver``
that uses it to evolve a generation prompt toward covering target directives.
Deterministic given a seed.
"""

from __future__ import annotations

import random
from collections.abc import Callable
from dataclasses import dataclass


@dataclass
class EvolutionConfig:
    population_size: int = 16
    generations: int = 10
    genome_length: int = 6
    mutation_rate: float = 0.3
    elitism: int = 2
    tournament_k: int = 3
    seed: int = 0


class GeneticOptimizer:
    """Evolves list-of-token genomes to maximize a fitness function."""

    def __init__(
        self,
        vocabulary: list[str],
        fitness: Callable[[list[str]], float],
        config: EvolutionConfig | None = None,
    ) -> None:
        if not vocabulary:
            raise ValueError("vocabulary must be non-empty")
        self.vocab = list(dict.fromkeys(vocabulary))  # dedupe, keep order
        self.fitness = fitness
        self.cfg = config or EvolutionConfig()
        self._rng = random.Random(self.cfg.seed)

    def _random_genome(self) -> list[str]:
        return [self._rng.choice(self.vocab) for _ in range(self.cfg.genome_length)]

    def _mutate(self, genome: list[str]) -> list[str]:
        g = list(genome)
        for i in range(len(g)):
            if self._rng.random() < self.cfg.mutation_rate:
                g[i] = self._rng.choice(self.vocab)
        return g

    def _crossover(self, a: list[str], b: list[str]) -> list[str]:
        if len(a) < 2:
            return list(a)
        point = self._rng.randint(1, len(a) - 1)
        return a[:point] + b[point:]

    def _tournament(self, scored: list[tuple[float, list[str]]]) -> list[str]:
        contenders = self._rng.sample(scored, min(self.cfg.tournament_k, len(scored)))
        return max(contenders, key=lambda x: x[0])[1]

    def run(self, seed_population: list[list[str]] | None = None) -> tuple[list[str], float, list[float]]:
        """Return (best_genome, best_fitness, best_per_generation_history)."""
        pop = seed_population or [self._random_genome() for _ in range(self.cfg.population_size)]
        history: list[float] = []
        best_genome: list[str] = pop[0]
        best_fit = float("-inf")

        for _ in range(self.cfg.generations):
            scored = sorted(((self.fitness(g), g) for g in pop), key=lambda x: x[0], reverse=True)
            if scored[0][0] > best_fit:
                best_fit, best_genome = scored[0][0], list(scored[0][1])
            history.append(scored[0][0])

            nxt: list[list[str]] = [list(g) for _, g in scored[: self.cfg.elitism]]
            while len(nxt) < self.cfg.population_size:
                parent_a = self._tournament(scored)
                parent_b = self._tournament(scored)
                child = self._mutate(self._crossover(parent_a, parent_b))
                nxt.append(child)
            pop = nxt

        return best_genome, best_fit, history


class PromptEvolver:
    """Evolves a generation prompt toward covering desired directives."""

    def __init__(
        self,
        directives: list[str],
        must_include: list[str],
        *,
        config: EvolutionConfig | None = None,
    ) -> None:
        self.must_include = must_include
        vocab = list(dict.fromkeys(directives + must_include))
        self._opt = GeneticOptimizer(vocab, self._fitness, config)

    def _fitness(self, genome: list[str]) -> float:
        present = set(genome)
        covered = sum(1 for m in self.must_include if m in present)
        unique_bonus = len(present) / max(1, len(genome))   # reward diversity
        dup_penalty = (len(genome) - len(present)) * 0.1     # punish repeats
        return covered * 1.0 + unique_bonus - dup_penalty

    def evolve(self) -> tuple[str, float]:
        """Return (prompt_string, fitness). Prompt joins ordered unique directives."""
        genome, fit, _ = self._opt.run()
        ordered_unique = list(dict.fromkeys(genome))
        prompt = "Write an article that is " + ", ".join(ordered_unique) + "."
        return prompt, fit
