"""Plugin API with hot-reload (persona-engine DNA).

Drop ``*.py`` files into a plugins directory; each defines::

    def register(registry):
        registry.add("my_writer", SomeWriter())

``PluginManager.discover()`` loads them; ``reload_if_changed()`` re-imports only
files whose mtime changed — enabling live iteration without restarting the engine.
"""

from __future__ import annotations

import importlib.util
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger("monolith.generation.plugins")


class Registry:
    """Name -> object map that plugins populate."""

    def __init__(self) -> None:
        self._items: dict[str, Any] = {}

    def add(self, name: str, obj: Any) -> None:
        self._items[name] = obj

    def get(self, name: str) -> Any:
        return self._items.get(name)

    def names(self) -> list[str]:
        return sorted(self._items)

    def __contains__(self, name: str) -> bool:
        return name in self._items

    def __len__(self) -> int:
        return len(self._items)


class PluginManager:
    """Discovers and hot-reloads plugin modules from a directory."""

    def __init__(self, plugin_dir: Path | str) -> None:
        self.plugin_dir = Path(plugin_dir)
        self.registry = Registry()
        self._mtimes: dict[Path, float] = {}

    def _load_file(self, path: Path) -> None:
        spec = importlib.util.spec_from_file_location(f"monolith_plugin_{path.stem}", path)
        if spec is None or spec.loader is None:
            return
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        register = getattr(module, "register", None)
        if callable(register):
            register(self.registry)
            logger.info("loaded plugin: %s", path.name)
        self._mtimes[path] = path.stat().st_mtime

    def discover(self) -> list[str]:
        """Load all plugins found in the directory. Returns registered names."""
        if not self.plugin_dir.exists():
            return self.registry.names()
        for path in sorted(self.plugin_dir.glob("*.py")):
            if path.name.startswith("_"):
                continue
            self._load_file(path)
        return self.registry.names()

    def reload_if_changed(self) -> list[Path]:
        """Re-import plugin files whose mtime changed. Returns reloaded paths."""
        reloaded: list[Path] = []
        if not self.plugin_dir.exists():
            return reloaded
        for path in sorted(self.plugin_dir.glob("*.py")):
            if path.name.startswith("_"):
                continue
            mtime = path.stat().st_mtime
            if self._mtimes.get(path) != mtime:
                self._load_file(path)
                reloaded.append(path)
        return reloaded
