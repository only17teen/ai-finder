"""Generation stage: turn topics into persona-authored posts.

Reads topics from the context bus (``ctx['topics']``) or derives them from
discovered items, runs each through a :class:`Writer` under a :class:`Persona`
(optionally with an evolved prompt), and writes ``ctx['posts']`` for the
output scaffolder to consume.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence

from ..core.pipeline import Context, Stage
from ..discovery.models import Item
from ..output.models import Post
from .evolution import PromptEvolver
from .models import Persona, Topic
from .writer import TemplateWriter, Writer


def items_to_topics(items: Sequence[Item]) -> list[Topic]:
    return [
        Topic(title=it.title or it.key, keywords=[it.key.split(".")[0]], context=it.text)
        for it in items
    ]


class GenerateStage(Stage):
    """Generate posts from topics using a persona + writer."""

    name = "generate"

    def __init__(
        self,
        persona: Persona,
        *,
        writer: Writer | None = None,
        prompt: str = "clear, well-structured, and SEO-friendly",
        evolver: PromptEvolver | None = None,
        from_items: bool = False,
        deps: Sequence[str] = (),
    ) -> None:
        super().__init__(name="generate", deps=deps)
        self._persona = persona
        self._writer: Writer = writer or TemplateWriter()
        self._prompt = prompt
        self._evolver = evolver
        self._from_items = from_items

    async def run(self, ctx: Context) -> dict[str, object]:
        topics: list[Topic] = ctx.get("topics", [])
        if not topics and self._from_items:
            topics = items_to_topics(ctx.get("items", []))

        prompt = self._prompt
        fitness = None
        if self._evolver is not None:
            prompt, fitness = self._evolver.evolve()
            ctx.meta["evolved_prompt"] = prompt
            ctx.meta["prompt_fitness"] = fitness

        async def _one(t: Topic) -> Post:
            body = await self._writer.write(t, self._persona, prompt)
            return Post(title=t.title, content_md=body, author=self._persona.name, tags=t.keywords)

        posts = await asyncio.gather(*(_one(t) for t in topics))
        ctx.put("posts", list(posts))
        return {"posts": len(posts), "prompt_fitness": fitness}
