"""Content writers: pluggable backends that turn a topic into Markdown.

``TemplateWriter`` is deterministic and offline — perfect for tests and
no-API runs. ``CallableWriter`` adapts any async function (e.g. an LLM call)
to the same interface, so swapping in a real model is a one-liner.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol, runtime_checkable

from .models import Persona, Topic


@runtime_checkable
class Writer(Protocol):
    """Produces a Markdown article body for a topic under a persona."""

    async def write(self, topic: Topic, persona: Persona, prompt: str) -> str: ...


class TemplateWriter:
    """Deterministic, dependency-free structured-article generator."""

    async def write(self, topic: Topic, persona: Persona, prompt: str) -> str:
        kws = topic.keywords or [topic.title.lower()]
        kw_line = ", ".join(kws)
        ctx = topic.context.strip()
        intro = (
            f"{topic.title} matters because {kws[0]} is reshaping how "
            f"{persona.audience} build and ship software."
        )
        if ctx:
            intro += f" {ctx}"

        parts = [
            f"# {topic.title}",
            "",
            f"*{persona.tone.capitalize()} notes by {persona.name}.*",
            "",
            "## Overview",
            "",
            intro,
            "",
            "## Why it matters",
            "",
            *[f"- **{k}** — a concrete reason {topic.title} is worth your attention." for k in kws[:4]],
            "",
            "## How it works",
            "",
            (
                f"At its core, {topic.title} combines {kw_line} into a single, "
                f"coherent approach. The result is {persona.voice}."
            ),
            "",
            "## Takeaways",
            "",
            "1. Start small and measure.",
            "2. Automate the repetitive parts.",
            "3. Ship, observe, iterate.",
        ]
        if persona.signature:
            parts += ["", f"— {persona.signature}"]
        return "\n".join(parts)


class CallableWriter:
    """Wrap an async ``fn(prompt) -> str`` (e.g. an LLM) as a :class:`Writer`."""

    def __init__(self, fn: Callable[[str], Awaitable[str]]) -> None:
        self._fn = fn

    async def write(self, topic: Topic, persona: Persona, prompt: str) -> str:
        full = f"{persona.style_brief()}\n\n{prompt}\n\nTopic: {topic.title}"
        return await self._fn(full)
