"""Generation subsystem (persona-engine DNA): persona writers, prompt
evolution, and a hot-reloadable plugin system."""

from .evolution import EvolutionConfig, GeneticOptimizer, PromptEvolver
from .models import Persona, Topic
from .plugins import PluginManager, Registry
from .stage import GenerateStage, items_to_topics
from .writer import CallableWriter, TemplateWriter, Writer

__all__ = [
    "Persona",
    "Topic",
    "Writer",
    "TemplateWriter",
    "CallableWriter",
    "GeneticOptimizer",
    "PromptEvolver",
    "EvolutionConfig",
    "PluginManager",
    "Registry",
    "GenerateStage",
    "items_to_topics",
]
