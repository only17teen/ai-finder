"""Pydantic v2 configuration schema for the Monolith Engine.

A single, validated config object drives the whole engine. Heavy/optional
subsystems (discovery, generation, deploy) hang off this root so one file
describes an entire run.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator


class RetryConfig(BaseModel):
    """Exponential-backoff retry policy."""

    max_attempts: int = Field(3, ge=1, le=20)
    base_delay: float = Field(0.1, ge=0, description="Seconds before first retry (0 = immediate).")
    max_delay: float = Field(10.0, gt=0, description="Upper bound on any single delay.")
    jitter: float = Field(0.1, ge=0, description="Random fraction added to each delay.")

    @field_validator("max_delay")
    @classmethod
    def _max_ge_base(cls, v: float, info: Any) -> float:
        base = info.data.get("base_delay", 0.0)
        if v < base:
            raise ValueError("max_delay must be >= base_delay")
        return v


class CircuitConfig(BaseModel):
    """Circuit-breaker thresholds."""

    failure_threshold: int = Field(5, ge=1, description="Consecutive failures before opening.")
    reset_timeout: float = Field(30.0, gt=0, description="Seconds open before half-open probe.")
    half_open_max_calls: int = Field(1, ge=1, description="Trial calls allowed while half-open.")


class PipelineConfig(BaseModel):
    """Execution policy for the stage DAG."""

    max_parallel: int = Field(8, ge=1, le=256, description="Max stages running concurrently.")
    stage_timeout: float = Field(120.0, gt=0, description="Per-stage timeout in seconds.")
    fail_fast: bool = Field(True, description="Abort the run on the first irrecoverable stage error.")


class EngineConfig(BaseModel):
    """Root configuration for an engine run."""

    project_name: str = Field("monolith-blog", min_length=1)
    workdir: Path = Field(Path("./.monolith"), description="Where checkpoints & artifacts live.")
    resume: bool = Field(True, description="Resume from checkpoint if one exists.")

    retry: RetryConfig = Field(default_factory=RetryConfig)
    circuit: CircuitConfig = Field(default_factory=CircuitConfig)
    pipeline: PipelineConfig = Field(default_factory=PipelineConfig)

    model_config = {"extra": "forbid"}

    @field_validator("workdir", mode="before")
    @classmethod
    def _coerce_path(cls, v: Any) -> Path:
        return Path(v) if not isinstance(v, Path) else v
