terraform {
  required_version = ">= 1.5"
  required_providers {
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = ">= 2.23"
    }
  }
}

variable "kubeconfig" {
  type        = string
  default     = "~/.kube/config"
  description = "Path to kubeconfig file."
}

variable "namespace" {
  type        = string
  default     = "monolith"
  description = "Kubernetes namespace to deploy into."
}

variable "image" {
  type        = string
  default     = "monolith-engine:latest"
  description = "Container image to deploy."
}

provider "kubernetes" {
  config_path = var.kubeconfig
}

resource "kubernetes_namespace" "monolith" {
  metadata {
    name = var.namespace
  }
}

resource "kubernetes_deployment" "monolith_engine" {
  metadata {
    name      = "monolith-engine"
    namespace = kubernetes_namespace.monolith.metadata[0].name
    labels    = { app = "monolith-engine" }
  }

  spec {
    replicas = 1
    selector {
      match_labels = { app = "monolith-engine" }
    }
    template {
      metadata {
        labels = { app = "monolith-engine" }
        annotations = {
          "prometheus.io/scrape" = "true"
          "prometheus.io/port"   = "9090"
        }
      }
      spec {
        container {
          name  = "monolith-engine"
          image = var.image
          args  = ["generate"]
          port {
            name           = "metrics"
            container_port = 9090
          }
          resources {
            requests = { cpu = "100m", memory = "128Mi" }
            limits   = { cpu = "500m", memory = "512Mi" }
          }
        }
      }
    }
  }
}

output "namespace" {
  value = kubernetes_namespace.monolith.metadata[0].name
}
