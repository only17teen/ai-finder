"""Tests for the observability subsystem (metrics + engine instrumentation)."""

from __future__ import annotations

import pytest

from monolith.config import EngineConfig
from monolith.core import Context, Engine, FnStage, Pipeline
from monolith.observability import (
    Counter,
    EngineMetrics,
    Gauge,
    Histogram,
    MetricsRegistry,
    build_engine_metrics,
)


# ----------------------------- counter ---------------------------------------
def test_counter_inc_and_labels():
    c = Counter(name="reqs", help="requests", labelnames=("method",))
    c.inc(method="GET")
    c.inc(2, method="GET")
    c.inc(method="POST")
    assert c.value(method="GET") == 3
    assert c.value(method="POST") == 1


def test_counter_rejects_decrease_and_bad_labels():
    c = Counter(name="x", help="x", labelnames=("a",))
    with pytest.raises(ValueError):
        c.inc(-1, a="1")
    with pytest.raises(ValueError):
        c.inc(b="1")  # wrong label


# ----------------------------- gauge -----------------------------------------
def test_gauge_set_inc_dec():
    g = Gauge(name="temp", help="t")
    g.set(10)
    g.inc(5)
    g.dec(3)
    assert g.value() == 12


# ----------------------------- histogram -------------------------------------
def test_histogram_render_has_bucket_sum_count():
    h = Histogram("lat", "latency", ("op",), buckets=(0.1, 1.0))
    h.observe(0.05, op="read")
    h.observe(0.5, op="read")
    h.observe(5.0, op="read")
    text = "\n".join(h.render())
    assert 'lat_bucket{op="read",le="0.1"} 1' in text
    assert 'lat_bucket{op="read",le="1.0"} 2' in text
    assert 'lat_bucket{op="read",le="+Inf"} 3' in text
    assert 'lat_count{op="read"} 3' in text
    assert "lat_sum" in text


# ----------------------------- registry render -------------------------------
def test_registry_render_prometheus_format():
    reg = MetricsRegistry()
    c = reg.counter("hits", "hit count")
    c.inc(4)
    out = reg.render()
    assert "# HELP hits hit count" in out
    assert "# TYPE hits counter" in out
    assert "hits 4" in out
    assert out.endswith("\n")


# ----------------------------- engine integration ----------------------------
async def test_engine_records_metrics(tmp_path):
    metrics = build_engine_metrics()

    async def ok(ctx: Context) -> str:
        return "ok"

    async def boom(ctx: Context) -> str:
        raise RuntimeError("x")

    pipe = (
        Pipeline()
        .add(FnStage("a", ok))
        .add(FnStage("b", boom, deps=["a"]))
    )
    cfg = EngineConfig(
        project_name="m", workdir=tmp_path, resume=False,
        retry={"max_attempts": 1, "base_delay": 0.0, "jitter": 0.0},
    )
    report = await Engine(cfg, pipe, metrics=metrics).run()

    assert not report.ok
    text = metrics.registry.render()
    assert 'monolith_stage_total{stage="a",status="ok"} 1' in text
    assert 'monolith_stage_total{stage="b",status="fail"} 1' in text
    assert 'monolith_run_total{outcome="failed"} 1' in text
    assert "monolith_stage_duration_seconds_count" in text


def test_engine_metrics_helper_builds_standard_set():
    m = build_engine_metrics()
    assert isinstance(m, EngineMetrics)
    m.record_stage("collect", "ok", 0.5)
    m.record_run(True)
    text = m.registry.render()
    assert 'monolith_stage_total{stage="collect",status="ok"} 1' in text
    assert 'monolith_run_total{outcome="ok"} 1' in text
