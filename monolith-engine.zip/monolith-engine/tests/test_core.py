"""Test suite for the Monolith Engine core."""

from __future__ import annotations

import asyncio

import pytest
from pydantic import ValidationError

from monolith.config import EngineConfig
from monolith.core import (
    CircuitBreaker,
    CircuitOpenError,
    CircuitState,
    Context,
    DependencyError,
    Engine,
    FnStage,
    Pipeline,
    RetryExhaustedError,
    retry_async,
)
from monolith.core.checkpoint import Checkpoint


# ----------------------------- config ---------------------------------------
def test_config_defaults_valid():
    cfg = EngineConfig(project_name="x")
    assert cfg.pipeline.max_parallel == 8
    assert cfg.retry.max_attempts == 3


def test_config_rejects_unknown_field():
    with pytest.raises(ValidationError):
        EngineConfig(project_name="x", bogus=1)  # type: ignore[call-arg]


def test_config_max_delay_must_exceed_base():
    with pytest.raises(ValidationError):
        EngineConfig(retry={"base_delay": 5.0, "max_delay": 1.0})


# ----------------------------- retry -----------------------------------------
async def test_retry_succeeds_after_failures():
    calls = {"n": 0}

    async def flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise RuntimeError("boom")
        return "ok"

    out = await retry_async(flaky, max_attempts=5, base_delay=0.0, jitter=0.0)
    assert out == "ok"
    assert calls["n"] == 3


async def test_retry_exhausted_raises():
    async def always_fail():
        raise ValueError("nope")

    with pytest.raises(RetryExhaustedError) as ei:
        await retry_async(always_fail, max_attempts=3, base_delay=0.0, jitter=0.0)
    assert ei.value.attempts == 3
    assert isinstance(ei.value.last_error, ValueError)


# ----------------------------- circuit breaker -------------------------------
async def test_breaker_opens_after_threshold():
    cb = CircuitBreaker(failure_threshold=2, reset_timeout=60.0)

    async def fail():
        raise RuntimeError("x")

    for _ in range(2):
        with pytest.raises(RuntimeError):
            await cb.call(fail)
    assert cb.state is CircuitState.OPEN
    with pytest.raises(CircuitOpenError):
        await cb.call(fail)


async def test_breaker_half_open_then_closes():
    clock = {"t": 0.0}
    cb = CircuitBreaker(
        failure_threshold=1, reset_timeout=10.0, time_fn=lambda: clock["t"]
    )

    async def fail():
        raise RuntimeError("x")

    async def ok():
        return 42

    with pytest.raises(RuntimeError):
        await cb.call(fail)
    assert cb.state is CircuitState.OPEN

    clock["t"] = 11.0  # past reset timeout -> half-open on next call
    assert await cb.call(ok) == 42
    assert cb.state is CircuitState.CLOSED


# ----------------------------- pipeline DAG ----------------------------------
def _noop(name):
    async def _fn(ctx: Context):
        return name

    return _fn


def test_topological_levels_diamond():
    p = (
        Pipeline()
        .add(FnStage("a", _noop("a")))
        .add(FnStage("b", _noop("b"), deps=["a"]))
        .add(FnStage("c", _noop("c"), deps=["a"]))
        .add(FnStage("d", _noop("d"), deps=["b", "c"]))
    )
    levels = p.topological_levels()
    assert levels[0] == ["a"]
    assert levels[1] == ["b", "c"]
    assert levels[2] == ["d"]


def test_missing_dependency_raises():
    p = Pipeline().add(FnStage("a", _noop("a"), deps=["ghost"]))
    with pytest.raises(DependencyError):
        p.topological_levels()


def test_cycle_detected():
    p = (
        Pipeline()
        .add(FnStage("a", _noop("a"), deps=["b"]))
        .add(FnStage("b", _noop("b"), deps=["a"]))
    )
    with pytest.raises(DependencyError):
        p.topological_levels()


def test_duplicate_stage_rejected():
    p = Pipeline().add(FnStage("a", _noop("a")))
    with pytest.raises(DependencyError):
        p.add(FnStage("a", _noop("a")))


# ----------------------------- checkpoint ------------------------------------
def test_checkpoint_roundtrip(tmp_path):
    cp = Checkpoint(tmp_path / "cp.json")
    assert not cp.is_done("s1")
    cp.mark("s1", {"v": 1})
    assert cp.is_done("s1")
    # reload from disk
    cp2 = Checkpoint(tmp_path / "cp.json")
    assert cp2.is_done("s1")
    assert cp2.completed["s1"] == {"v": 1}
    cp2.clear()
    assert not (tmp_path / "cp.json").exists()


# ----------------------------- engine end-to-end -----------------------------
async def test_engine_runs_dag_in_order(tmp_path):
    order: list[str] = []

    def stage(name):
        async def _fn(ctx: Context):
            order.append(name)
            return name

        return _fn

    p = (
        Pipeline()
        .add(FnStage("discover", stage("discover")))
        .add(FnStage("score", stage("score"), deps=["discover"]))
        .add(FnStage("build", stage("build"), deps=["score"]))
    )
    cfg = EngineConfig(project_name="t", workdir=tmp_path, resume=False)
    report = await Engine(cfg, p).run()
    assert report.ok
    assert report.succeeded == ["discover", "score", "build"]
    assert order == ["discover", "score", "build"]


async def test_engine_resumes_from_checkpoint(tmp_path):
    runs: list[str] = []

    def stage(name, boom=False):
        async def _fn(ctx: Context):
            runs.append(name)
            if boom:
                raise RuntimeError("explode")
            return name

        return _fn

    # First run: 'b' explodes, fail-fast aborts before 'c'.
    p1 = (
        Pipeline()
        .add(FnStage("a", stage("a")))
        .add(FnStage("b", stage("b", boom=True), deps=["a"]))
        .add(FnStage("c", stage("c"), deps=["b"]))
    )
    cfg = EngineConfig(
        project_name="t", workdir=tmp_path, resume=True,
        retry={"max_attempts": 1, "base_delay": 0.0, "jitter": 0.0},
    )
    r1 = await Engine(cfg, p1).run()
    assert not r1.ok
    assert "a" in r1.succeeded
    assert "b" in r1.failed

    # Second run: 'b' fixed. 'a' should be skipped (checkpointed), b & c run.
    runs.clear()
    p2 = (
        Pipeline()
        .add(FnStage("a", stage("a")))
        .add(FnStage("b", stage("b"), deps=["a"]))
        .add(FnStage("c", stage("c"), deps=["b"]))
    )
    r2 = await Engine(cfg, p2).run()
    assert r2.ok
    assert "a" in r2.skipped
    assert runs == ["b", "c"]


async def test_engine_parallel_level_runs_concurrently(tmp_path):
    active = {"now": 0, "max": 0}

    def stage(name):
        async def _fn(ctx: Context):
            active["now"] += 1
            active["max"] = max(active["max"], active["now"])
            await asyncio.sleep(0.05)
            active["now"] -= 1
            return name

        return _fn

    p = Pipeline().add(FnStage("root", stage("root")))
    for i in range(4):
        p.add(FnStage(f"leaf{i}", stage(f"leaf{i}"), deps=["root"]))

    cfg = EngineConfig(project_name="t", workdir=tmp_path, resume=False)
    report = await Engine(cfg, p).run()
    assert report.ok
    assert active["max"] >= 2  # leaves overlapped
