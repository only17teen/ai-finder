"""Tests for the declarative run-config loader."""

from __future__ import annotations

import json

import pytest

from monolith.config import EngineConfig
from monolith.core import Context, Engine
from monolith.generation.models import Persona, Topic
from monolith.loaders import RunSpec, build_blog_pipeline, load_run_config

_CONFIG = {
    "project_name": "loaded-blog",
    "resume": False,
    "pipeline": {"max_parallel": 4},
    "site": {
        "name": "Loaded Blog",
        "url": "https://blog.example.com",
        "description": "from config",
        "author": "tester",
    },
    "persona": {"name": "Tester", "tone": "punchy"},
    "topics": [
        {"title": "First Topic", "keywords": ["a", "b"]},
        {"title": "Second Topic"},
    ],
}


def test_load_run_config_json(tmp_path):
    cfg = tmp_path / "run.json"
    cfg.write_text(json.dumps(_CONFIG))
    spec = load_run_config(cfg)
    assert isinstance(spec, RunSpec)
    assert spec.engine.project_name == "loaded-blog"
    assert spec.engine.pipeline.max_parallel == 4
    assert spec.site.name == "Loaded Blog"
    assert spec.persona.tone == "punchy"
    assert len(spec.topics) == 2
    assert spec.topics[0].keywords == ["a", "b"]


def test_load_run_config_yaml(tmp_path):
    yaml = pytest.importorskip("yaml")
    cfg = tmp_path / "run.yaml"
    cfg.write_text(yaml.safe_dump(_CONFIG))
    spec = load_run_config(cfg)
    assert spec.engine.project_name == "loaded-blog"
    assert len(spec.topics) == 2


def test_loader_rejects_unknown_engine_field(tmp_path):
    bad = dict(_CONFIG, bogus_field=1)
    cfg = tmp_path / "run.json"
    cfg.write_text(json.dumps(bad))
    # unknown top-level keys are ignored (not passed to EngineConfig),
    # so this still loads — verify it doesn't crash and ignores extras
    spec = load_run_config(cfg)
    assert spec.engine.project_name == "loaded-blog"


async def test_run_from_config_end_to_end(tmp_path):
    out_dir = tmp_path / "site"
    config = dict(_CONFIG, out_dir=str(out_dir))
    cfg = tmp_path / "run.json"
    cfg.write_text(json.dumps(config))

    spec = load_run_config(cfg)
    # redirect engine workdir into tmp
    spec.engine = EngineConfig(**{**spec.engine.model_dump(), "workdir": tmp_path})
    pipe = build_blog_pipeline(spec)
    ctx = Context()
    ctx.put("topics", spec.topics)
    report = await Engine(spec.engine, pipe).run(ctx)

    assert report.ok
    assert report.succeeded == ["generate", "scaffold"]
    assert (out_dir / "package.json").exists()
    posts_ts = (out_dir / "src/content/posts.ts").read_text()
    assert "First Topic" in posts_ts and "Second Topic" in posts_ts
