"""Tests for the discovery subsystem (collect, dedup, score, store)."""

from __future__ import annotations

import pytest

from monolith.config import EngineConfig
from monolith.core import Context, Engine, Pipeline
from monolith.discovery import (
    CollectStage,
    Collector,
    DedupStage,
    Item,
    LSHIndex,
    MinHasher,
    ScoreStage,
    SQLiteStore,
    StaticCollector,
    StoreStage,
    deduplicate,
    default_scorer,
    run_collectors,
)


# ----------------------------- models ----------------------------------------
def test_item_key_is_domain():
    a = Item(url="https://www.geekai.co/pricing")
    b = Item(url="https://geekai.co/docs")
    assert a.key == "geekai.co"
    assert a.key == b.key  # same domain -> same identity


# ----------------------------- minhash / lsh ---------------------------------
def test_minhash_identical_text_jaccard_one():
    h = MinHasher(num_perm=64, seed=7)
    s = h.signature("the quick brown fox jumps over the lazy dog repeatedly")
    assert MinHasher.jaccard(s, s) == 1.0


def test_minhash_disjoint_text_low_jaccard():
    h = MinHasher(num_perm=128, seed=7)
    s1 = h.signature("alpha beta gamma delta epsilon zeta eta theta")
    s2 = h.signature("one two three four five six seven eight nine")
    assert MinHasher.jaccard(s1, s2) < 0.2


def test_lsh_finds_similar_candidate():
    h = MinHasher(num_perm=64, seed=1)
    idx = LSHIndex(num_perm=64, bands=16)
    base = "production grade async pipeline for ai model generation via comfyui api"
    idx.add("a", h.signature(base))
    near = h.signature(base + " with extra trailing words")
    assert "a" in idx.candidates(near)


def test_lsh_invalid_bands():
    with pytest.raises(ValueError):
        LSHIndex(num_perm=64, bands=10)


# ----------------------------- deduplicate -----------------------------------
def test_dedup_exact_domain():
    items = [
        Item(url="https://x.com/a", title="A"),
        Item(url="https://x.com/b", title="B"),  # same domain -> dropped
        Item(url="https://y.com/a", title="C"),
    ]
    unique, dropped = deduplicate(items)
    assert {it.key for it in unique} == {"x.com", "y.com"}
    assert dropped == 1


def test_dedup_near_duplicate_across_domains():
    text = "discover niche ai services with apis and referral programs by crawling sources"
    items = [
        Item(url="https://a.com", title="AI Finder", text=text),
        Item(url="https://b.com", title="AI Finder", text=text + " ignored by mainstream"),
    ]
    unique, dropped = deduplicate(items, threshold=0.6)
    assert len(unique) == 1
    assert dropped == 1


# ----------------------------- scorer ----------------------------------------
def test_default_scorer_bounds_and_ordering():
    poor = Item(url="https://a.com")  # no title, no text
    rich = Item(url="https://b.com", title="Great", text="word " * 300)
    assert default_scorer(poor) == 0.0
    assert default_scorer(rich) == pytest.approx(1.0)
    assert 0.0 <= default_scorer(Item(url="https://c.com", title="Hi")) <= 1.0


# ----------------------------- collectors ------------------------------------
async def test_run_collectors_isolates_failures():
    class Boom(Collector):
        name = "boom"

        async def collect(self):
            raise RuntimeError("down")

    good = StaticCollector("good", [Item(url="https://ok.com", title="ok")])
    items, errors = await run_collectors([good, Boom()])
    assert len(items) == 1
    assert "boom" in errors
    assert items[0].source == "good"


# ----------------------------- store -----------------------------------------
async def test_store_upsert_and_top(tmp_path):
    store = SQLiteStore(tmp_path / "d.db")
    await store.init()
    await store.upsert(
        [
            Item(url="https://a.com", title="A", score=0.2),
            Item(url="https://b.com", title="B", score=0.9),
        ]
    )
    assert await store.count() == 2
    top = await store.top(1)
    assert top[0].key == "b.com"
    # upsert keeps the MAX score
    await store.upsert([Item(url="https://a.com", title="A", score=0.5)])
    assert await store.count() == 2
    rows = {it.key: it.score for it in await store.top(10)}
    assert rows["a.com"] == 0.5


# ----------------------------- full discovery pipeline -----------------------
async def test_discovery_pipeline_end_to_end(tmp_path):
    dup_text = "same body text repeated across two different source domains here"
    collectors = [
        StaticCollector(
            "src1",
            [
                Item(url="https://alpha.com", title="Alpha", text="word " * 250),
                Item(url="https://beta.com", title="Beta", text=dup_text),
            ],
        ),
        StaticCollector(
            "src2",
            [
                Item(url="https://alpha.com/other", title="Alpha dup"),  # exact domain dup
                Item(url="https://gamma.com", title="Gamma", text=dup_text),  # near dup of beta
            ],
        ),
    ]
    db = tmp_path / "disc.db"
    pipe = (
        Pipeline()
        .add(CollectStage(collectors))
        .add(DedupStage(threshold=0.6))
        .add(ScoreStage())
        .add(StoreStage(db))
    )
    cfg = EngineConfig(project_name="disc", workdir=tmp_path, resume=False)
    ctx = Context()
    report = await Engine(cfg, pipe).run(ctx)

    assert report.ok
    assert report.succeeded == ["collect", "dedup", "score", "store"]
    # 4 collected -> alpha domain dup removed -> beta/gamma near-dup collapsed
    final_keys = {it.key for it in ctx.get("items")}
    assert "alpha.com" in final_keys
    assert len(final_keys) == 2  # alpha + one of (beta/gamma)
    assert ctx.meta["store_count"] == 2
    # highest-scored (alpha, rich text) ranked first
    assert ctx.get("items")[0].key == "alpha.com"
