"""Tests for the output subsystem (markdown, scaffolder, pipeline)."""

from __future__ import annotations

import json

import pytest

from monolith.config import EngineConfig
from monolith.core import Context, Engine, Pipeline
from monolith.discovery import CollectStage, DedupStage, Item, ScoreStage, StaticCollector
from monolith.output import (
    NextScaffolder,
    Post,
    ScaffoldStage,
    SiteConfig,
    items_to_posts,
    md_to_html,
    slugify,
)


# ----------------------------- markdown --------------------------------------
def test_md_headings_and_inline():
    html = md_to_html("# Title\n\nSome **bold** and *italic* and `code`.")
    assert "<h1>Title</h1>" in html
    assert "<strong>bold</strong>" in html
    assert "<em>italic</em>" in html
    assert "<code>code</code>" in html


def test_md_code_fence_and_list():
    html = md_to_html("```python\nprint(1)\n```\n\n- one\n- two")
    assert '<pre><code class="language-python">' in html
    assert "print(1)" in html
    assert "<ul><li>one</li><li>two</li></ul>" in html


def test_md_link_and_escaping():
    html = md_to_html("See [docs](https://x.com) & <tag>.")
    assert '<a href="https://x.com">docs</a>' in html
    assert "&lt;tag&gt;" in html  # raw HTML escaped


# ----------------------------- models ----------------------------------------
def test_slugify():
    assert slugify("Hello, World!") == "hello-world"
    assert slugify("  Multi   Space ") == "multi-space"


def test_post_auto_fields():
    p = Post(title="My First Post", content_md="word " * 250)
    assert p.slug == "my-first-post"
    assert p.date  # auto today
    assert p.excerpt  # auto from content
    assert p.reading_time == 1 or p.reading_time >= 1


# ----------------------------- scaffolder ------------------------------------
def _site() -> SiteConfig:
    return SiteConfig(url="https://blog.example.com", name="Test Blog", description="hi", author="t")


async def test_scaffolder_writes_full_tree(tmp_path):
    posts = [
        Post(title="Async Engines", content_md="# Async\n\nDeep dive into **async**."),
        Post(title="Edge AI", content_md="Running models at the edge."),
    ]
    scaffolder = NextScaffolder(_site(), posts)
    written = await scaffolder.build(tmp_path)

    must_have = {
        "package.json",
        "next.config.mjs",
        "tsconfig.json",
        "tailwind.config.ts",
        "src/app/layout.tsx",
        "src/app/page.tsx",
        "src/app/blog/[slug]/page.tsx",
        "src/app/sitemap.ts",
        "src/app/robots.ts",
        "src/content/posts.ts",
        "src/lib/posts.ts",
        "src/types/index.ts",
    }
    assert must_have <= set(written)
    for rel in must_have:
        assert (tmp_path / rel).exists()


async def test_package_and_tsconfig_are_valid_json(tmp_path):
    await NextScaffolder(_site(), []).build(tmp_path)
    pkg = json.loads((tmp_path / "package.json").read_text())
    assert pkg["name"] == "test-blog"
    assert "next" in pkg["dependencies"]
    tsconfig = json.loads((tmp_path / "tsconfig.json").read_text())
    assert tsconfig["compilerOptions"]["strict"] is True


async def test_posts_data_module_embeds_rendered_html(tmp_path):
    posts = [Post(title="Hello", content_md="# Hello\n\nWorld **bold**.")]
    await NextScaffolder(_site(), posts).build(tmp_path)
    body = (tmp_path / "src/content/posts.ts").read_text()
    # the TS module should contain a parseable JSON array after the assignment
    arr_text = body.split("= ", 1)[1].rstrip().rstrip(";")
    data = json.loads(arr_text)
    assert data[0]["slug"] == "hello"
    assert "<strong>bold</strong>" in data[0]["html"]
    assert data[0]["readingTime"] >= 1


async def test_seo_artifacts_present(tmp_path):
    await NextScaffolder(_site(), [Post(title="A", content_md="x")]).build(tmp_path)
    post_page = (tmp_path / "src/app/blog/[slug]/page.tsx").read_text()
    assert "generateStaticParams" in post_page
    assert "generateMetadata" in post_page
    assert "application/ld+json" in post_page  # JSON-LD structured data
    site_ts = (tmp_path / "src/lib/site.ts").read_text()
    assert "blog.example.com" in site_ts


async def test_tag_pages_generated(tmp_path):
    posts = [
        Post(title="A", content_md="x", tags=["async", "ai"]),
        Post(title="B", content_md="y", tags=["ai"]),
    ]
    await NextScaffolder(_site(), posts).build(tmp_path)
    assert (tmp_path / "src/app/tags/page.tsx").exists()
    tag_page = (tmp_path / "src/app/tags/[tag]/page.tsx").read_text()
    assert "generateStaticParams" in tag_page
    assert "getPostsByTag" in tag_page
    lib = (tmp_path / "src/lib/posts.ts").read_text()
    assert "getPostsByTag" in lib


async def test_rss_feed_generated(tmp_path):
    import xml.etree.ElementTree as ET

    posts = [Post(title="Hello & Co", content_md="body", tags=["news"])]
    await NextScaffolder(_site(), posts).build(tmp_path)
    feed = tmp_path / "public/feed.xml"
    assert feed.exists()
    root = ET.fromstring(feed.read_text())  # well-formed XML (escaping correct)
    assert root.tag == "rss"
    titles = [t.text for t in root.iter("title")]
    assert "Hello & Co" in titles  # ampersand correctly escaped/parsed


async def test_sitemap_includes_tags(tmp_path):
    await NextScaffolder(_site(), [Post(title="A", content_md="x", tags=["ai"])]).build(tmp_path)
    sitemap = (tmp_path / "src/app/sitemap.ts").read_text()
    assert "getAllTags" in sitemap
    assert "/tags/" in sitemap


def test_no_unreplaced_sentinels(tmp_path):
    import asyncio

    asyncio.run(NextScaffolder(_site(), [Post(title="A", content_md="x")]).build(tmp_path))
    for path in tmp_path.rglob("*"):
        if path.is_file():
            assert "%%" not in path.read_text(), f"unreplaced sentinel in {path}"


# ----------------------------- adapter ---------------------------------------
def test_items_to_posts():
    items = [Item(url="https://x.com", title="X Post", text="body here")]
    posts = items_to_posts(items)
    assert posts[0].title == "X Post"
    assert posts[0].content_md == "body here"


# ----------------------------- full pipeline ---------------------------------
async def test_discovery_to_output_pipeline(tmp_path):
    out_dir = tmp_path / "site"
    collectors = [
        StaticCollector(
            "seed",
            [
                Item(url="https://a.com", title="First", text="word " * 120),
                Item(url="https://b.com", title="Second", text="edge ai content"),
            ],
        )
    ]
    site = SiteConfig(url="https://blog.example.com", name="Engine Blog", description="d")
    pipe = (
        Pipeline()
        .add(CollectStage(collectors))
        .add(DedupStage())
        .add(ScoreStage())
        .add(ScaffoldStage(site, out_dir, deps=["score"], from_items=True))
    )
    cfg = EngineConfig(project_name="full", workdir=tmp_path, resume=False)
    ctx = Context()
    report = await Engine(cfg, pipe).run(ctx)

    assert report.ok
    assert report.succeeded == ["collect", "dedup", "score", "scaffold"]
    assert (out_dir / "package.json").exists()
    assert (out_dir / "src/app/blog/[slug]/page.tsx").exists()
    posts_ts = (out_dir / "src/content/posts.ts").read_text()
    assert "First" in posts_ts and "Second" in posts_ts
