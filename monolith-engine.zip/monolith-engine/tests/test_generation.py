"""Tests for the generation subsystem (writer, evolution, plugins, pipeline)."""

from __future__ import annotations

import pytest

from monolith.config import EngineConfig
from monolith.core import Context, Engine, Pipeline
from monolith.discovery import CollectStage, DedupStage, Item, StaticCollector
from monolith.generation import (
    CallableWriter,
    EvolutionConfig,
    GenerateStage,
    GeneticOptimizer,
    Persona,
    PluginManager,
    PromptEvolver,
    Registry,
    TemplateWriter,
    Topic,
    items_to_topics,
)
from monolith.output import ScaffoldStage, SiteConfig


# ----------------------------- persona / writer ------------------------------
async def test_template_writer_is_deterministic():
    p = Persona(name="Engine", signature="Engine")
    t = Topic(title="Async Pipelines", keywords=["async", "pipelines"])
    w = TemplateWriter()
    a = await w.write(t, p, "prompt")
    b = await w.write(t, p, "prompt")
    assert a == b
    assert "# Async Pipelines" in a
    assert "**async**" in a
    assert "Engine" in a


def test_persona_style_brief():
    p = Persona(name="X", tone="punchy", audience="founders", traits=["bold"])
    brief = p.style_brief()
    assert "punchy" in brief and "founders" in brief and "bold" in brief


async def test_callable_writer_adapts_async_fn():
    async def fake_llm(prompt: str) -> str:
        return f"GENERATED for: {prompt[-12:]}"

    w = CallableWriter(fake_llm)
    out = await w.write(Topic(title="Edge AI"), Persona(name="N"), "be concise")
    assert out.startswith("GENERATED for:")


# ----------------------------- genetic optimizer -----------------------------
def test_optimizer_improves_over_generations():
    # fitness: count of target tokens present
    targets = {"a", "b", "c"}

    def fitness(g):
        return sum(1 for x in set(g) if x in targets)

    opt = GeneticOptimizer(
        vocabulary=["a", "b", "c", "x", "y", "z"],
        fitness=fitness,
        config=EvolutionConfig(seed=42, generations=20, population_size=20, genome_length=6),
    )
    best, score, history = opt.run()
    assert score == 3  # all three targets found
    assert set(targets) <= set(best)
    assert history[-1] >= history[0]  # best never regresses


def test_optimizer_empty_vocab_raises():
    with pytest.raises(ValueError):
        GeneticOptimizer([], lambda g: 0.0)


def test_prompt_evolver_covers_required_directives():
    evolver = PromptEvolver(
        directives=["concise", "engaging", "verbose", "rambling"],
        must_include=["seo-friendly", "well-structured"],
        config=EvolutionConfig(seed=7, generations=25, population_size=24, genome_length=5),
    )
    prompt, fit = evolver.evolve()
    assert "seo-friendly" in prompt
    assert "well-structured" in prompt
    assert prompt.startswith("Write an article that is")


# ----------------------------- plugins / hot reload --------------------------
def test_plugin_discover_and_hot_reload(tmp_path):
    plug = tmp_path / "myplug.py"
    plug.write_text(
        "def register(reg):\n    reg.add('greeting', 'hello')\n", encoding="utf-8"
    )
    mgr = PluginManager(tmp_path)
    names = mgr.discover()
    assert "greeting" in names
    assert mgr.registry.get("greeting") == "hello"

    # change the plugin -> hot reload picks it up
    import os, time

    new_mtime = plug.stat().st_mtime + 10
    plug.write_text(
        "def register(reg):\n    reg.add('greeting', 'bonjour')\n", encoding="utf-8"
    )
    os.utime(plug, (new_mtime, new_mtime))
    reloaded = mgr.reload_if_changed()
    assert plug in reloaded
    assert mgr.registry.get("greeting") == "bonjour"


def test_registry_basics():
    r = Registry()
    r.add("w", object())
    assert "w" in r and len(r) == 1 and r.names() == ["w"]


# ----------------------------- adapters --------------------------------------
def test_items_to_topics():
    topics = items_to_topics([Item(url="https://geekai.co", title="GeekAI", text="ctx")])
    assert topics[0].title == "GeekAI"
    assert topics[0].keywords == ["geekai"]
    assert topics[0].context == "ctx"


# ----------------------------- full pipeline ---------------------------------
async def test_generate_stage_produces_posts():
    persona = Persona(name="Monolith", signature="— Monolith")
    ctx = Context()
    ctx.put("topics", [Topic(title="One Engine", keywords=["async"])])
    stage = GenerateStage(persona)
    out = await stage.run(ctx)
    assert out["posts"] == 1
    posts = ctx.get("posts")
    assert posts[0].author == "Monolith"
    assert "# One Engine" in posts[0].content_md


async def test_discover_generate_scaffold_pipeline(tmp_path):
    out_dir = tmp_path / "site"
    collectors = [
        StaticCollector(
            "seed",
            [
                Item(url="https://a.com", title="Async Engines", text="async pipelines rock"),
                Item(url="https://b.com", title="Edge AI", text="models at the edge"),
            ],
        )
    ]
    persona = Persona(name="Monolith", tone="punchy")
    evolver = PromptEvolver(
        directives=["concise", "practical"],
        must_include=["seo-friendly"],
        config=EvolutionConfig(seed=1, generations=10, population_size=12, genome_length=4),
    )
    site = SiteConfig(url="https://blog.example.com", name="Engine Blog", description="d")

    pipe = (
        Pipeline()
        .add(CollectStage(collectors))
        .add(DedupStage())
        .add(GenerateStage(persona, evolver=evolver, from_items=True, deps=["dedup"]))
        .add(ScaffoldStage(site, out_dir, deps=["generate"]))
    )
    cfg = EngineConfig(project_name="full2", workdir=tmp_path, resume=False)
    ctx = Context()
    report = await Engine(cfg, pipe).run(ctx)

    assert report.ok
    assert report.succeeded == ["collect", "dedup", "generate", "scaffold"]
    assert "seo-friendly" in ctx.meta["evolved_prompt"]
    posts_ts = (out_dir / "src/content/posts.ts").read_text()
    assert "Async Engines" in posts_ts and "Edge AI" in posts_ts
    # posts were AI-authored by the persona (template writer signature present)
    assert "Monolith" in posts_ts
