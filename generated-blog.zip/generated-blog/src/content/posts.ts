import type { Post } from "@/types";

export const posts: Post[] = [
  {
    "slug": "building-one-engine",
    "title": "Building One Engine",
    "excerpt": "Building One Engine\n\nPunchy notes by only17teen.\n\n Overview\n\nBuilding One Engine matters because async is reshaping how developers build and ship software.\n\n…",
    "date": "2026-06-17",
    "author": "only17teen",
    "tags": [
      "async",
      "pipeline"
    ],
    "coverImage": "",
    "html": "<h1>Building One Engine</h1>\n<p><em>Punchy notes by only17teen.</em></p>\n<h2>Overview</h2>\n<p>Building One Engine matters because async is reshaping how developers build and ship software.</p>\n<h2>Why it matters</h2>\n<ul><li><strong>async</strong> — a concrete reason Building One Engine is worth your attention.</li><li><strong>pipeline</strong> — a concrete reason Building One Engine is worth your attention.</li></ul>\n<h2>How it works</h2>\n<p>At its core, Building One Engine combines async, pipeline into a single, coherent approach. The result is clear, technical, and confident.</p>\n<h2>Takeaways</h2>\n<ol><li>Start small and measure.</li><li>Automate the repetitive parts.</li><li>Ship, observe, iterate.</li></ol>\n<p>— only17teen</p>",
    "readingTime": 1
  },
  {
    "slug": "edge-first-static-sites",
    "title": "Edge-First Static Sites",
    "excerpt": "EdgeFirst Static Sites\n\nPunchy notes by only17teen.\n\n Overview\n\nEdgeFirst Static Sites matters because nextjs is reshaping how developers build and ship soft…",
    "date": "2026-06-17",
    "author": "only17teen",
    "tags": [
      "nextjs",
      "performance"
    ],
    "coverImage": "",
    "html": "<h1>Edge-First Static Sites</h1>\n<p><em>Punchy notes by only17teen.</em></p>\n<h2>Overview</h2>\n<p>Edge-First Static Sites matters because nextjs is reshaping how developers build and ship software.</p>\n<h2>Why it matters</h2>\n<ul><li><strong>nextjs</strong> — a concrete reason Edge-First Static Sites is worth your attention.</li><li><strong>performance</strong> — a concrete reason Edge-First Static Sites is worth your attention.</li></ul>\n<h2>How it works</h2>\n<p>At its core, Edge-First Static Sites combines nextjs, performance into a single, coherent approach. The result is clear, technical, and confident.</p>\n<h2>Takeaways</h2>\n<ol><li>Start small and measure.</li><li>Automate the repetitive parts.</li><li>Ship, observe, iterate.</li></ol>\n<p>— only17teen</p>",
    "readingTime": 1
  }
];
