import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import { getAllTags, getPostsByTag } from "@/lib/posts";
import { site } from "@/lib/site";

export function generateStaticParams() {
  return getAllTags().map((tag) => ({ tag }));
}

export function generateMetadata({ params }: { params: { tag: string } }): Metadata {
  return {
    title: `#${params.tag}`,
    description: `Posts tagged ${params.tag} on ${site.name}.`,
    alternates: { canonical: `${site.url}/tags/${params.tag}` },
  };
}

export default function TagPage({ params }: { params: { tag: string } }) {
  const posts = getPostsByTag(params.tag);
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">#{params.tag}</h1>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        {posts.map((post) => (
          <PostCard key={post.slug} post={post} />
        ))}
      </div>
    </div>
  );
}
