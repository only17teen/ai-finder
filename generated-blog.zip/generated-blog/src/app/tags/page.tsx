import Link from "next/link";
import { getAllTags } from "@/lib/posts";

export const metadata = { title: "Tags" };

export default function TagsPage() {
  const tags = getAllTags();
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">Tags</h1>
      <ul className="flex flex-wrap gap-3">
        {tags.map((tag) => (
          <li key={tag}>
            <Link
              href={`/tags/${tag}`}
              className="rounded-full border border-gray-200 px-3 py-1 text-sm text-gray-700 hover:border-gray-300 dark:border-gray-800 dark:text-gray-300"
            >
              #{tag}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
