import type { MetadataRoute } from "next";
import { getAllPosts, getAllTags } from "@/lib/posts";
import { site } from "@/lib/site";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const posts = getAllPosts().map((p) => ({
    url: `${site.url}/blog/${p.slug}`,
    lastModified: p.date,
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));
  const tags = getAllTags().map((t) => ({
    url: `${site.url}/tags/${t}`,
    changeFrequency: "weekly" as const,
    priority: 0.5,
  }));
  return [
    { url: site.url, lastModified: new Date().toISOString(), changeFrequency: "daily", priority: 1 },
    { url: `${site.url}/tags`, changeFrequency: "weekly", priority: 0.4 },
    ...posts,
    ...tags,
  ];
}
