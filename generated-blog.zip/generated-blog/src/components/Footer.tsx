import { site } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="border-t border-gray-200 dark:border-gray-800">
      <div className="mx-auto w-full max-w-3xl px-4 py-8 text-sm text-gray-500 dark:text-gray-400">
        © {new Date().getFullYear()} {site.name}. Built with Monolith Engine.
      </div>
    </footer>
  );
}
