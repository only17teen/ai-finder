import Link from "next/link";
import type { Post } from "@/types";

export default function PostCard({ post }: { post: Post }) {
  return (
    <Link
      href={`/blog/${post.slug}`}
      className="group flex flex-col rounded-xl border border-gray-200 p-5 transition hover:border-gray-300 hover:shadow-sm dark:border-gray-800 dark:hover:border-gray-700"
    >
      <h2 className="text-lg font-semibold tracking-tight group-hover:underline">{post.title}</h2>
      <p className="mt-2 line-clamp-3 text-sm text-gray-600 dark:text-gray-400">{post.excerpt}</p>
      <span className="mt-4 text-xs text-gray-500 dark:text-gray-500">
        {post.date} · {post.readingTime} min read
      </span>
    </Link>
  );
}
