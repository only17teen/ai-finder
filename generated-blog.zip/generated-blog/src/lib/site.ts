export const site = {
  name: "Monolith Blog",
  url: "https://blog.example.com",
  description: "Engine-generated, persona-authored, SEO-optimized.",
  author: "only17teen",
  locale: "en",
} as const;
