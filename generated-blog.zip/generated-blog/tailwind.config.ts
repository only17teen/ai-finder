import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "media",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { accent: "#3b82f6" },
    },
  },
  plugins: [],
};

export default config;
